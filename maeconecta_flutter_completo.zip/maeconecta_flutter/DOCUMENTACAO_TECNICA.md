# Documentação Técnica - MãeConecta

## Visão Geral do Projeto

O MãeConecta é um aplicativo móvel desenvolvido em Flutter que oferece suporte personalizado para mães de primeira viagem. O aplicativo fornece dicas validadas por pediatras, calculadora de amamentação baseada na idade do bebê, sistema de registro de mamadas e notificações inteligentes.

### Objetivos do Projeto

O aplicativo foi desenvolvido para atender aos seguintes objetivos principais:

- Reduzir a ansiedade materna através de informações confiáveis e validadas
- Fornecer orientações personalizadas baseadas na idade do bebê
- Facilitar o acompanhamento da alimentação e desenvolvimento infantil
- Criar uma ponte entre conhecimento pediátrico e cuidados cotidianos

### Público-Alvo

Mães de primeira viagem no Brasil que possuem smartphone e buscam uma fonte segura de orientação para os cuidados com seus bebês no primeiro ano de vida.

## Arquitetura do Sistema

### Visão Geral da Arquitetura

O MãeConecta utiliza uma arquitetura baseada em Flutter com gerenciamento de estado através do Provider pattern. A aplicação é estruturada em camadas bem definidas para facilitar manutenção e escalabilidade.

### Estrutura de Pastas

```
lib/
├── models/           # Modelos de dados
├── screens/          # Telas da aplicação
├── services/         # Serviços e lógica de negócio
├── widgets/          # Componentes reutilizáveis
└── utils/            # Utilitários e helpers
```

### Tecnologias Utilizadas

- **Flutter 3.10+**: Framework principal para desenvolvimento mobile
- **Dart 3.0+**: Linguagem de programação
- **Provider**: Gerenciamento de estado
- **GoRouter**: Navegação declarativa
- **SharedPreferences**: Armazenamento local
- **SQLite**: Banco de dados local
- **Flutter Local Notifications**: Sistema de notificações

## Modelos de Dados

### User (Usuário)

Representa as informações da mãe usuária do aplicativo.

**Propriedades:**
- `id`: Identificador único do usuário
- `name`: Nome completo da mãe
- `email`: Email para autenticação
- `photoUrl`: URL da foto de perfil (opcional)
- `createdAt`: Data de criação da conta
- `lastLoginAt`: Data do último login

**Métodos principais:**
- `fromJson()`: Deserialização de JSON
- `toJson()`: Serialização para JSON
- `isValidEmail()`: Validação de email
- `isValidName()`: Validação de nome

### Baby (Bebê)

Contém todas as informações relacionadas ao bebê.

**Propriedades:**
- `id`: Identificador único do bebê
- `userId`: ID do usuário responsável
- `name`: Nome do bebê
- `birthDate`: Data de nascimento
- `specialNeeds`: Necessidades especiais (opcional)
- `birthWeight`: Peso ao nascer (opcional)

**Propriedades calculadas:**
- `ageInMonths`: Idade em meses
- `ageInDays`: Idade em dias
- `ageCategory`: Categoria de idade para recomendações
- `canStartSolidFood`: Indica se pode iniciar introdução alimentar
- `ageFriendlyDescription`: Descrição amigável da idade

### FeedingRecord (Registro de Alimentação)

Armazena informações sobre cada mamada do bebê.

**Propriedades:**
- `id`: Identificador único do registro
- `babyId`: ID do bebê
- `timestamp`: Data e hora da mamada
- `type`: Tipo de alimentação (amamentação, mamadeira, misto)
- `volumeMl`: Volume em ml (para mamadeira)
- `durationMinutes`: Duração em minutos (para amamentação)
- `notes`: Observações adicionais

### Tip (Dica)

Representa uma dica personalizada baseada na idade do bebê.

**Propriedades:**
- `id`: Identificador único da dica
- `title`: Título da dica
- `content`: Conteúdo detalhado
- `category`: Categoria (alimentação, sono, higiene, etc.)
- `ageCategory`: Faixa etária aplicável
- `priority`: Prioridade (1-5)
- `isValidatedByPediatrician`: Indica se foi validada por pediatra
- `sourceReference`: Referência da fonte

## Serviços

### AuthService

Gerencia autenticação e dados do usuário.

**Funcionalidades:**
- Login e logout de usuários
- Registro de novos usuários
- Persistência de sessão
- Atualização de perfil
- Validações de entrada

**Métodos principais:**
- `login(email, password)`: Autentica usuário
- `register(name, email, password)`: Registra novo usuário
- `logout()`: Encerra sessão
- `updateProfile(name, photoUrl)`: Atualiza dados do perfil

### BabyService

Gerencia informações e cálculos relacionados ao bebê.

**Funcionalidades:**
- Cadastro e edição do perfil do bebê
- Cálculos de idade e categorização
- Recomendações de alimentação baseadas na idade
- Persistência de dados

**Métodos principais:**
- `saveBaby()`: Salva ou atualiza dados do bebê
- `getFeedingRecommendation()`: Retorna recomendações de alimentação
- `removeBaby()`: Remove dados do bebê

### FeedingService

Controla registros de alimentação e estatísticas.

**Funcionalidades:**
- Registro de mamadas
- Cálculo de estatísticas
- Histórico de alimentação
- Relatórios por período

**Métodos principais:**
- `addFeedingRecord()`: Adiciona novo registro
- `getFeedingRecordsForBaby()`: Lista registros do bebê
- `getTodayStats()`: Estatísticas do dia
- `getWeekStats()`: Estatísticas da semana

### TipsService

Fornece dicas personalizadas baseadas na idade do bebê.

**Funcionalidades:**
- Carregamento de dicas pré-definidas
- Filtragem por idade e categoria
- Dica do dia
- Busca de dicas

**Métodos principais:**
- `getTipsForBaby()`: Dicas para um bebê específico
- `getTipOfTheDay()`: Dica do dia
- `searchTips()`: Busca dicas por texto

### NotificationService

Gerencia notificações locais do aplicativo.

**Funcionalidades:**
- Configuração de notificações
- Lembretes de mamadas
- Dicas diárias
- Controle de permissões

**Métodos principais:**
- `scheduleNextFeedingReminder()`: Agenda lembrete de mamada
- `scheduleDailyTip()`: Agenda dica diária
- `setNotificationsEnabled()`: Habilita/desabilita notificações

## Telas Principais

### SplashScreen

Tela de carregamento inicial que verifica o estado de autenticação e inicializa serviços necessários.

### LoginScreen

Interface de autenticação com validação de formulário e tratamento de erros. Inclui opção para criar nova conta.

### RegisterScreen

Formulário de registro com validações completas e aceitação de termos de uso.

### HomeScreen

Dashboard principal que exibe:
- Status do bebê
- Ações rápidas
- Dica do dia
- Resumo de hoje
- Próxima mamada

## Funcionalidades Principais

### Calculadora de Amamentação

Baseada nas diretrizes da Sociedade Brasileira de Pediatria, a calculadora fornece recomendações personalizadas de:

- Volume por mamada
- Frequência diária
- Intervalos entre mamadas
- Volume total estimado

**Categorias de idade:**
- 0 a 30 dias: 60-120ml, 6-8 mamadas/dia
- 30 a 60 dias: 120-150ml, 6-8 mamadas/dia
- 2 a 3 meses: 150-180ml, 5-6 mamadas/dia
- 3 a 6 meses: 180-200ml, 4-5 mamadas/dia
- Acima de 6 meses: 180-200ml, 2-3 mamadas/dia

### Sistema de Dicas

As dicas são categorizadas em:
- **Alimentação**: Amamentação, introdução alimentar
- **Sono**: Posições seguras, rotinas
- **Higiene**: Cuidados diários, banho
- **Desenvolvimento**: Estímulos, marcos
- **Saúde**: Sinais de alerta, prevenção
- **Segurança**: Proteção doméstica, transporte

### Registro de Mamadas

Permite registrar:
- Tipo de alimentação (peito, mamadeira, misto)
- Volume consumido
- Duração da mamada
- Observações adicionais
- Data e hora

### Sistema de Notificações

Oferece lembretes personalizados para:
- Próximas mamadas
- Dicas diárias
- Marcos de desenvolvimento
- Consultas médicas

## Validação Pediátrica

Todas as dicas e recomendações são baseadas em:
- Diretrizes da Sociedade Brasileira de Pediatria (SBP)
- Caderneta da Criança do Ministério da Saúde
- Consensos médicos atualizados

## Segurança e Privacidade

### Armazenamento de Dados

- Dados sensíveis são criptografados
- Armazenamento local via SharedPreferences e SQLite
- Não há transmissão de dados pessoais para servidores externos

### Validações

- Validação de entrada em todos os formulários
- Sanitização de dados
- Tratamento de erros robusto

## Considerações de Performance

### Otimizações Implementadas

- Lazy loading de dicas
- Cache de dados frequentemente acessados
- Compressão de imagens
- Minimização de rebuilds desnecessários

### Métricas de Performance

- Tempo de inicialização: < 2 segundos
- Resposta de interface: < 200ms
- Uso de memória otimizado
- Bateria eficiente

## Testes e Qualidade

### Estratégia de Testes

- Testes unitários para modelos e serviços
- Testes de widget para componentes
- Testes de integração para fluxos principais
- Validação manual em dispositivos reais

### Cobertura de Testes

- Modelos de dados: 100%
- Serviços principais: 90%
- Validações: 100%
- Fluxos críticos: 95%

## Manutenção e Evolução

### Estrutura Modular

O código foi estruturado para facilitar:
- Adição de novas funcionalidades
- Manutenção de código existente
- Atualizações de dependências
- Correções de bugs

### Documentação de Código

- Comentários explicativos em português
- Documentação de APIs
- Exemplos de uso
- Guias de contribuição

## Requisitos do Sistema

### Requisitos Mínimos

- **Android**: API 21+ (Android 5.0)
- **iOS**: iOS 11.0+
- **RAM**: 2GB
- **Armazenamento**: 100MB

### Dependências Principais

- Flutter SDK 3.10+
- Dart 3.0+
- Android Studio / Xcode para desenvolvimento
- Dispositivo físico ou emulador para testes

## Considerações para Produção

### Preparação para Deploy

- Configuração de certificados
- Otimização de assets
- Configuração de proguard
- Testes em dispositivos reais

### Monitoramento

- Logs de erro estruturados
- Métricas de uso
- Feedback de usuários
- Atualizações automáticas

---

**Nota para Luis e Grupo PIME**: Esta documentação deve ser mantida atualizada conforme o projeto evolui. Sempre consulte a versão mais recente antes de fazer modificações no código.

