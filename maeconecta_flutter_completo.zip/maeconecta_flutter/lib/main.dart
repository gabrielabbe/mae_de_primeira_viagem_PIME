// NOTA PARA LUIS E GRUPO PIME:
// Este é o arquivo principal do aplicativo MãeConecta.
// Configura o tema, navegação e providers globais.

import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'package:go_router/go_router.dart';
import 'package:flutter_local_notifications/flutter_local_notifications.dart';

import 'screens/splash_screen.dart';
import 'screens/login_screen.dart';
import 'screens/register_screen.dart';
import 'screens/home_screen.dart';
import 'screens/baby_profile_screen.dart';
import 'screens/feeding_calculator_screen.dart';
import 'screens/tips_screen.dart';
import 'screens/feeding_log_screen.dart';
import 'screens/profile_screen.dart';
import 'services/auth_service.dart';
import 'services/baby_service.dart';
import 'services/feeding_service.dart';
import 'services/tips_service.dart';
import 'services/notification_service.dart';

// Plugin de notificações locais
final FlutterLocalNotificationsPlugin flutterLocalNotificationsPlugin =
    FlutterLocalNotificationsPlugin();

void main() async {
  WidgetsFlutterBinding.ensureInitialized();
  
  // Inicializar notificações
  await NotificationService.initialize();
  
  runApp(const MaeConectaApp());
}

class MaeConectaApp extends StatelessWidget {
  const MaeConectaApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MultiProvider(
      providers: [
        ChangeNotifierProvider(create: (_) => AuthService()),
        ChangeNotifierProvider(create: (_) => BabyService()),
        ChangeNotifierProvider(create: (_) => FeedingService()),
        ChangeNotifierProvider(create: (_) => TipsService()),
      ],
      child: Consumer<AuthService>(
        builder: (context, authService, _) {
          return MaterialApp.router(
            title: 'MãeConecta',
            debugShowCheckedModeBanner: false,
            theme: _buildTheme(),
            routerConfig: _buildRouter(authService),
          );
        },
      ),
    );
  }

  // Configuração do tema do aplicativo
  ThemeData _buildTheme() {
    return ThemeData(
      useMaterial3: true,
      colorScheme: ColorScheme.fromSeed(
        seedColor: const Color(0xFF6B73FF),
        brightness: Brightness.light,
      ),
      appBarTheme: const AppBarTheme(
        centerTitle: true,
        elevation: 0,
        backgroundColor: Colors.transparent,
        foregroundColor: Color(0xFF2D3748),
      ),
      cardTheme: CardTheme(
        elevation: 2,
        shape: RoundedRectangleBorder(
          borderRadius: BorderRadius.circular(12),
        ),
      ),
      elevatedButtonTheme: ElevatedButtonThemeData(
        style: ElevatedButton.styleFrom(
          elevation: 0,
          padding: const EdgeInsets.symmetric(horizontal: 24, vertical: 12),
          shape: RoundedRectangleBorder(
            borderRadius: BorderRadius.circular(8),
          ),
        ),
      ),
      inputDecorationTheme: InputDecorationTheme(
        border: OutlineInputBorder(
          borderRadius: BorderRadius.circular(8),
        ),
        contentPadding: const EdgeInsets.symmetric(horizontal: 16, vertical: 12),
      ),
      fontFamily: 'Roboto',
    );
  }

  // Configuração das rotas do aplicativo
  GoRouter _buildRouter(AuthService authService) {
    return GoRouter(
      initialLocation: '/splash',
      redirect: (context, state) {
        final isLoggedIn = authService.isLoggedIn;
        final isLoading = authService.isLoading;
        
        // Se ainda está carregando, mostrar splash
        if (isLoading) {
          return '/splash';
        }
        
        // Se não está logado e não está na tela de login/registro
        if (!isLoggedIn && 
            !state.location.startsWith('/login') && 
            !state.location.startsWith('/register') &&
            state.location != '/splash') {
          return '/login';
        }
        
        // Se está logado e está na tela de login/splash
        if (isLoggedIn && 
            (state.location.startsWith('/login') || 
             state.location.startsWith('/register') ||
             state.location == '/splash')) {
          return '/home';
        }
        
        return null;
      },
      routes: [
        GoRoute(
          path: '/splash',
          builder: (context, state) => const SplashScreen(),
        ),
        GoRoute(
          path: '/login',
          builder: (context, state) => const LoginScreen(),
        ),
        GoRoute(
          path: '/register',
          builder: (context, state) => const RegisterScreen(),
        ),
        GoRoute(
          path: '/home',
          builder: (context, state) => const HomeScreen(),
        ),
        GoRoute(
          path: '/baby-profile',
          builder: (context, state) => const BabyProfileScreen(),
        ),
        GoRoute(
          path: '/feeding-calculator',
          builder: (context, state) => const FeedingCalculatorScreen(),
        ),
        GoRoute(
          path: '/tips',
          builder: (context, state) => const TipsScreen(),
        ),
        GoRoute(
          path: '/feeding-log',
          builder: (context, state) => const FeedingLogScreen(),
        ),
        GoRoute(
          path: '/profile',
          builder: (context, state) => const ProfileScreen(),
        ),
      ],
    );
  }
}

