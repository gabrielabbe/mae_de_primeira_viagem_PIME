// NOTA PARA LUIS E GRUPO PIME:
// Este serviço gerencia as notificações locais do aplicativo.
// Permite agendar lembretes de mamadas e dicas diárias.

import 'package:flutter/foundation.dart';
import 'package:flutter_local_notifications/flutter_local_notifications.dart';
import 'package:shared_preferences/shared_preferences.dart';

class NotificationService {
  static final FlutterLocalNotificationsPlugin _notifications =
      FlutterLocalNotificationsPlugin();

  static bool _isInitialized = false;

  // Inicializa o serviço de notificações
  static Future<void> initialize() async {
    if (_isInitialized) return;

    const androidSettings = AndroidInitializationSettings('@mipmap/ic_launcher');
    const iosSettings = DarwinInitializationSettings(
      requestAlertPermission: true,
      requestBadgePermission: true,
      requestSoundPermission: true,
    );

    const initSettings = InitializationSettings(
      android: androidSettings,
      iOS: iosSettings,
    );

    await _notifications.initialize(
      initSettings,
      onDidReceiveNotificationResponse: _onNotificationTapped,
    );

    _isInitialized = true;
  }

  // Callback quando notificação é tocada
  static void _onNotificationTapped(NotificationResponse response) {
    debugPrint('Notificação tocada: ${response.payload}');
    // Aqui você pode navegar para uma tela específica baseada no payload
  }

  // Solicita permissões (principalmente para iOS)
  static Future<bool> requestPermissions() async {
    final result = await _notifications
        .resolvePlatformSpecificImplementation<
            IOSFlutterLocalNotificationsPlugin>()
        ?.requestPermissions(
          alert: true,
          badge: true,
          sound: true,
        );
    
    return result ?? true; // Android não precisa de permissão explícita
  }

  // Mostra notificação imediata
  static Future<void> showNotification({
    required int id,
    required String title,
    required String body,
    String? payload,
  }) async {
    const androidDetails = AndroidNotificationDetails(
      'maeconecta_channel',
      'MãeConecta',
      channelDescription: 'Notificações do aplicativo MãeConecta',
      importance: Importance.high,
      priority: Priority.high,
      icon: '@mipmap/ic_launcher',
    );

    const iosDetails = DarwinNotificationDetails(
      presentAlert: true,
      presentBadge: true,
      presentSound: true,
    );

    const details = NotificationDetails(
      android: androidDetails,
      iOS: iosDetails,
    );

    await _notifications.show(id, title, body, details, payload: payload);
  }

  // Agenda notificação para um horário específico
  static Future<void> scheduleNotification({
    required int id,
    required String title,
    required String body,
    required DateTime scheduledDate,
    String? payload,
  }) async {
    const androidDetails = AndroidNotificationDetails(
      'maeconecta_scheduled',
      'MãeConecta Agendadas',
      channelDescription: 'Notificações agendadas do MãeConecta',
      importance: Importance.high,
      priority: Priority.high,
      icon: '@mipmap/ic_launcher',
    );

    const iosDetails = DarwinNotificationDetails(
      presentAlert: true,
      presentBadge: true,
      presentSound: true,
    );

    const details = NotificationDetails(
      android: androidDetails,
      iOS: iosDetails,
    );

    await _notifications.zonedSchedule(
      id,
      title,
      body,
      scheduledDate,
      details,
      payload: payload,
      uiLocalNotificationDateInterpretation:
          UILocalNotificationDateInterpretation.absoluteTime,
    );
  }

  // Agenda notificação recorrente diária
  static Future<void> scheduleDailyNotification({
    required int id,
    required String title,
    required String body,
    required Time time,
    String? payload,
  }) async {
    const androidDetails = AndroidNotificationDetails(
      'maeconecta_daily',
      'MãeConecta Diárias',
      channelDescription: 'Notificações diárias do MãeConecta',
      importance: Importance.high,
      priority: Priority.high,
      icon: '@mipmap/ic_launcher',
    );

    const iosDetails = DarwinNotificationDetails(
      presentAlert: true,
      presentBadge: true,
      presentSound: true,
    );

    const details = NotificationDetails(
      android: androidDetails,
      iOS: iosDetails,
    );

    await _notifications.periodicallyShow(
      id,
      title,
      body,
      RepeatInterval.daily,
      details,
      payload: payload,
    );
  }

  // Cancela notificação específica
  static Future<void> cancelNotification(int id) async {
    await _notifications.cancel(id);
  }

  // Cancela todas as notificações
  static Future<void> cancelAllNotifications() async {
    await _notifications.cancelAll();
  }

  // Obtém notificações pendentes
  static Future<List<PendingNotificationRequest>> getPendingNotifications() async {
    return await _notifications.pendingNotificationRequests();
  }

  // Verifica se notificações estão habilitadas
  static Future<bool> areNotificationsEnabled() async {
    final prefs = await SharedPreferences.getInstance();
    return prefs.getBool('notifications_enabled') ?? true;
  }

  // Habilita/desabilita notificações
  static Future<void> setNotificationsEnabled(bool enabled) async {
    final prefs = await SharedPreferences.getInstance();
    await prefs.setBool('notifications_enabled', enabled);
    
    if (!enabled) {
      await cancelAllNotifications();
    }
  }

  // Agenda lembrete de próxima mamada
  static Future<void> scheduleNextFeedingReminder({
    required Duration interval,
    String? babyName,
  }) async {
    final enabled = await areNotificationsEnabled();
    if (!enabled) return;

    const notificationId = 1001;
    final scheduledTime = DateTime.now().add(interval);
    
    await scheduleNotification(
      id: notificationId,
      title: 'Hora da mamada! 🍼',
      body: babyName != null 
          ? 'É hora de alimentar $babyName'
          : 'É hora de alimentar o bebê',
      scheduledDate: scheduledTime,
      payload: 'feeding_reminder',
    );
  }

  // Agenda dica diária
  static Future<void> scheduleDailyTip() async {
    final enabled = await areNotificationsEnabled();
    if (!enabled) return;

    const notificationId = 2001;
    
    await scheduleDailyNotification(
      id: notificationId,
      title: 'Dica do dia! 💡',
      body: 'Confira sua dica personalizada de hoje',
      time: const Time(9, 0), // 9:00 AM
      payload: 'daily_tip',
    );
  }

  // Cancela lembrete de mamada
  static Future<void> cancelFeedingReminder() async {
    await cancelNotification(1001);
  }

  // Cancela dica diária
  static Future<void> cancelDailyTip() async {
    await cancelNotification(2001);
  }
}

