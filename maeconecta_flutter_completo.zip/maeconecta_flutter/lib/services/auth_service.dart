// NOTA PARA LUIS E GRUPO PIME:
// Este serviço gerencia a autenticação do usuário.
// Utiliza SharedPreferences para persistir dados localmente.

import 'package:flutter/foundation.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'dart:convert';
import '../models/user.dart';

class AuthService extends ChangeNotifier {
  User? _currentUser;
  bool _isLoading = true;
  String? _errorMessage;

  User? get currentUser => _currentUser;
  bool get isLoggedIn => _currentUser != null;
  bool get isLoading => _isLoading;
  String? get errorMessage => _errorMessage;

  AuthService() {
    _loadUserFromStorage();
  }

  // Carrega usuário do armazenamento local
  Future<void> _loadUserFromStorage() async {
    try {
      final prefs = await SharedPreferences.getInstance();
      final userJson = prefs.getString('current_user');
      
      if (userJson != null) {
        final userMap = json.decode(userJson);
        _currentUser = User.fromJson(userMap);
      }
    } catch (e) {
      debugPrint('Erro ao carregar usuário: $e');
    } finally {
      _isLoading = false;
      notifyListeners();
    }
  }

  // Salva usuário no armazenamento local
  Future<void> _saveUserToStorage(User user) async {
    try {
      final prefs = await SharedPreferences.getInstance();
      final userJson = json.encode(user.toJson());
      await prefs.setString('current_user', userJson);
    } catch (e) {
      debugPrint('Erro ao salvar usuário: $e');
    }
  }

  // Remove usuário do armazenamento local
  Future<void> _removeUserFromStorage() async {
    try {
      final prefs = await SharedPreferences.getInstance();
      await prefs.remove('current_user');
    } catch (e) {
      debugPrint('Erro ao remover usuário: $e');
    }
  }

  // Simula login (em produção, conectar com API real)
  Future<bool> login(String email, String password) async {
    try {
      _isLoading = true;
      _errorMessage = null;
      notifyListeners();

      // Simular delay de rede
      await Future.delayed(const Duration(seconds: 1));

      // Validações básicas
      if (!User.isValidEmail(email)) {
        _errorMessage = 'Email inválido';
        return false;
      }

      if (password.length < 6) {
        _errorMessage = 'Senha deve ter pelo menos 6 caracteres';
        return false;
      }

      // Simular autenticação (substituir por chamada real à API)
      if (email == 'teste@maeconecta.com' && password == '123456') {
        _currentUser = User(
          id: '1',
          name: 'Maria Silva',
          email: email,
          createdAt: DateTime.now(),
          lastLoginAt: DateTime.now(),
        );

        await _saveUserToStorage(_currentUser!);
        return true;
      } else {
        _errorMessage = 'Email ou senha incorretos';
        return false;
      }
    } catch (e) {
      _errorMessage = 'Erro ao fazer login: $e';
      return false;
    } finally {
      _isLoading = false;
      notifyListeners();
    }
  }

  // Simula registro (em produção, conectar com API real)
  Future<bool> register(String name, String email, String password) async {
    try {
      _isLoading = true;
      _errorMessage = null;
      notifyListeners();

      // Simular delay de rede
      await Future.delayed(const Duration(seconds: 1));

      // Validações
      if (!User.isValidName(name)) {
        _errorMessage = 'Nome deve ter pelo menos 2 caracteres';
        return false;
      }

      if (!User.isValidEmail(email)) {
        _errorMessage = 'Email inválido';
        return false;
      }

      if (password.length < 6) {
        _errorMessage = 'Senha deve ter pelo menos 6 caracteres';
        return false;
      }

      // Simular criação de usuário (substituir por chamada real à API)
      _currentUser = User(
        id: DateTime.now().millisecondsSinceEpoch.toString(),
        name: name,
        email: email,
        createdAt: DateTime.now(),
        lastLoginAt: DateTime.now(),
      );

      await _saveUserToStorage(_currentUser!);
      return true;
    } catch (e) {
      _errorMessage = 'Erro ao criar conta: $e';
      return false;
    } finally {
      _isLoading = false;
      notifyListeners();
    }
  }

  // Logout
  Future<void> logout() async {
    try {
      _isLoading = true;
      notifyListeners();

      await _removeUserFromStorage();
      _currentUser = null;
      _errorMessage = null;
    } catch (e) {
      debugPrint('Erro ao fazer logout: $e');
    } finally {
      _isLoading = false;
      notifyListeners();
    }
  }

  // Atualiza perfil do usuário
  Future<bool> updateProfile(String name, String? photoUrl) async {
    try {
      if (_currentUser == null) return false;

      _isLoading = true;
      notifyListeners();

      // Simular delay de rede
      await Future.delayed(const Duration(milliseconds: 500));

      // Validações
      if (!User.isValidName(name)) {
        _errorMessage = 'Nome deve ter pelo menos 2 caracteres';
        return false;
      }

      // Atualizar usuário
      _currentUser = _currentUser!.copyWith(
        name: name,
        photoUrl: photoUrl,
      );

      await _saveUserToStorage(_currentUser!);
      return true;
    } catch (e) {
      _errorMessage = 'Erro ao atualizar perfil: $e';
      return false;
    } finally {
      _isLoading = false;
      notifyListeners();
    }
  }

  // Limpa mensagem de erro
  void clearError() {
    _errorMessage = null;
    notifyListeners();
  }
}

