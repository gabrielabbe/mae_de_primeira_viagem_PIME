// NOTA PARA LUIS E GRUPO PIME:
// Este serviço gerencia os dados do bebê.
// Inclui cálculos de idade e recomendações de amamentação.

import 'package:flutter/foundation.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'dart:convert';
import '../models/baby.dart';

class BabyService extends ChangeNotifier {
  Baby? _currentBaby;
  bool _isLoading = false;
  String? _errorMessage;

  Baby? get currentBaby => _currentBaby;
  bool get isLoading => _isLoading;
  String? get errorMessage => _errorMessage;
  bool get hasBaby => _currentBaby != null;

  BabyService() {
    _loadBabyFromStorage();
  }

  // Carrega bebê do armazenamento local
  Future<void> _loadBabyFromStorage() async {
    try {
      _isLoading = true;
      notifyListeners();

      final prefs = await SharedPreferences.getInstance();
      final babyJson = prefs.getString('current_baby');
      
      if (babyJson != null) {
        final babyMap = json.decode(babyJson);
        _currentBaby = Baby.fromJson(babyMap);
      }
    } catch (e) {
      debugPrint('Erro ao carregar bebê: $e');
    } finally {
      _isLoading = false;
      notifyListeners();
    }
  }

  // Salva bebê no armazenamento local
  Future<void> _saveBabyToStorage(Baby baby) async {
    try {
      final prefs = await SharedPreferences.getInstance();
      final babyJson = json.encode(baby.toJson());
      await prefs.setString('current_baby', babyJson);
    } catch (e) {
      debugPrint('Erro ao salvar bebê: $e');
    }
  }

  // Cria ou atualiza perfil do bebê
  Future<bool> saveBaby({
    required String name,
    required DateTime birthDate,
    String? specialNeeds,
    double? birthWeight,
    required String userId,
  }) async {
    try {
      _isLoading = true;
      _errorMessage = null;
      notifyListeners();

      // Validações
      if (!Baby.isValidName(name)) {
        _errorMessage = 'Nome deve ter pelo menos 2 caracteres';
        return false;
      }

      if (!Baby.isValidBirthDate(birthDate)) {
        _errorMessage = 'Data de nascimento inválida';
        return false;
      }

      // Criar ou atualizar bebê
      if (_currentBaby == null) {
        _currentBaby = Baby(
          id: DateTime.now().millisecondsSinceEpoch.toString(),
          userId: userId,
          name: name,
          birthDate: birthDate,
          specialNeeds: specialNeeds,
          birthWeight: birthWeight,
          createdAt: DateTime.now(),
        );
      } else {
        _currentBaby = _currentBaby!.copyWith(
          name: name,
          birthDate: birthDate,
          specialNeeds: specialNeeds,
          birthWeight: birthWeight,
          updatedAt: DateTime.now(),
        );
      }

      await _saveBabyToStorage(_currentBaby!);
      return true;
    } catch (e) {
      _errorMessage = 'Erro ao salvar bebê: $e';
      return false;
    } finally {
      _isLoading = false;
      notifyListeners();
    }
  }

  // Calcula recomendações de amamentação baseadas na idade
  FeedingRecommendation? getFeedingRecommendation() {
    if (_currentBaby == null) return null;

    final ageCategory = _currentBaby!.ageCategory;
    
    switch (ageCategory) {
      case "0 a 30 dias":
        return FeedingRecommendation(
          ageCategory: ageCategory,
          volumeRange: const VolumeRange(min: 60, max: 120),
          feedingsPerDay: const FeedingRange(min: 6, max: 8),
          intervalHours: 3,
          notes: "Recém-nascidos precisam de alimentação frequente. "
                 "Observe sinais de fome e saciedade.",
        );
      case "30 a 60 dias":
        return FeedingRecommendation(
          ageCategory: ageCategory,
          volumeRange: const VolumeRange(min: 120, max: 150),
          feedingsPerDay: const FeedingRange(min: 6, max: 8),
          intervalHours: 3,
          notes: "O bebê já estabelece um padrão mais regular. "
                 "Continue observando os sinais de fome.",
        );
      case "2 a 3 meses":
        return FeedingRecommendation(
          ageCategory: ageCategory,
          volumeRange: const VolumeRange(min: 150, max: 180),
          feedingsPerDay: const FeedingRange(min: 5, max: 6),
          intervalHours: 4,
          notes: "O bebê pode ficar mais tempo entre as mamadas. "
                 "Padrão de sono também melhora.",
        );
      case "3 a 6 meses":
        return FeedingRecommendation(
          ageCategory: ageCategory,
          volumeRange: const VolumeRange(min: 180, max: 200),
          feedingsPerDay: const FeedingRange(min: 4, max: 5),
          intervalHours: 4,
          notes: "Preparação para introdução alimentar aos 6 meses. "
                 "Mantenha o leite como alimento principal.",
        );
      case "Acima de 6 meses":
        return FeedingRecommendation(
          ageCategory: ageCategory,
          volumeRange: const VolumeRange(min: 180, max: 200),
          feedingsPerDay: const FeedingRange(min: 2, max: 3),
          intervalHours: 6,
          notes: "Introdução alimentar iniciada. O leite continua importante "
                 "mas não é mais o único alimento.",
        );
      default:
        return null;
    }
  }

  // Remove bebê
  Future<void> removeBaby() async {
    try {
      final prefs = await SharedPreferences.getInstance();
      await prefs.remove('current_baby');
      _currentBaby = null;
      notifyListeners();
    } catch (e) {
      debugPrint('Erro ao remover bebê: $e');
    }
  }

  // Limpa mensagem de erro
  void clearError() {
    _errorMessage = null;
    notifyListeners();
  }
}

// Classes auxiliares para recomendações de alimentação
class FeedingRecommendation {
  final String ageCategory;
  final VolumeRange volumeRange;
  final FeedingRange feedingsPerDay;
  final int intervalHours;
  final String notes;

  FeedingRecommendation({
    required this.ageCategory,
    required this.volumeRange,
    required this.feedingsPerDay,
    required this.intervalHours,
    required this.notes,
  });

  int get averageVolume => ((volumeRange.min + volumeRange.max) / 2).round();
  int get averageFeedings => ((feedingsPerDay.min + feedingsPerDay.max) / 2).round();
  int get dailyVolumeEstimate => averageVolume * averageFeedings;
}

class VolumeRange {
  final int min;
  final int max;

  const VolumeRange({required this.min, required this.max});
}

class FeedingRange {
  final int min;
  final int max;

  const FeedingRange({required this.min, required this.max});
}

