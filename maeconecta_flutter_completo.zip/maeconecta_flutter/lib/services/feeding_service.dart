// NOTA PARA LUIS E GRUPO PIME:
// Este serviço gerencia os registros de alimentação do bebê.
// Permite adicionar, listar e gerar estatísticas das mamadas.

import 'package:flutter/foundation.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'dart:convert';
import '../models/feeding_record.dart';

class FeedingService extends ChangeNotifier {
  List<FeedingRecord> _feedingRecords = [];
  bool _isLoading = false;
  String? _errorMessage;

  List<FeedingRecord> get feedingRecords => List.unmodifiable(_feedingRecords);
  bool get isLoading => _isLoading;
  String? get errorMessage => _errorMessage;

  FeedingService() {
    _loadFeedingRecordsFromStorage();
  }

  // Carrega registros do armazenamento local
  Future<void> _loadFeedingRecordsFromStorage() async {
    try {
      _isLoading = true;
      notifyListeners();

      final prefs = await SharedPreferences.getInstance();
      final recordsJson = prefs.getStringList('feeding_records') ?? [];
      
      _feedingRecords = recordsJson
          .map((json) => FeedingRecord.fromJson(jsonDecode(json)))
          .toList();
      
      // Ordenar por data (mais recente primeiro)
      _feedingRecords.sort((a, b) => b.timestamp.compareTo(a.timestamp));
    } catch (e) {
      debugPrint('Erro ao carregar registros: $e');
    } finally {
      _isLoading = false;
      notifyListeners();
    }
  }

  // Salva registros no armazenamento local
  Future<void> _saveFeedingRecordsToStorage() async {
    try {
      final prefs = await SharedPreferences.getInstance();
      final recordsJson = _feedingRecords
          .map((record) => jsonEncode(record.toJson()))
          .toList();
      await prefs.setStringList('feeding_records', recordsJson);
    } catch (e) {
      debugPrint('Erro ao salvar registros: $e');
    }
  }

  // Adiciona novo registro de alimentação
  Future<bool> addFeedingRecord({
    required String babyId,
    required DateTime timestamp,
    required FeedingType type,
    int? volumeMl,
    int? durationMinutes,
    String? notes,
  }) async {
    try {
      _isLoading = true;
      _errorMessage = null;
      notifyListeners();

      // Validações
      if (type == FeedingType.bottle && (volumeMl == null || volumeMl <= 0)) {
        _errorMessage = 'Volume é obrigatório para mamadeira';
        return false;
      }

      if (type == FeedingType.breastfeeding && (durationMinutes == null || durationMinutes <= 0)) {
        _errorMessage = 'Duração é obrigatória para amamentação';
        return false;
      }

      if (timestamp.isAfter(DateTime.now())) {
        _errorMessage = 'Data não pode ser no futuro';
        return false;
      }

      // Criar novo registro
      final newRecord = FeedingRecord(
        id: DateTime.now().millisecondsSinceEpoch.toString(),
        babyId: babyId,
        timestamp: timestamp,
        type: type,
        volumeMl: volumeMl,
        durationMinutes: durationMinutes,
        notes: notes,
        createdAt: DateTime.now(),
      );

      _feedingRecords.insert(0, newRecord); // Adicionar no início (mais recente)
      await _saveFeedingRecordsToStorage();
      
      return true;
    } catch (e) {
      _errorMessage = 'Erro ao adicionar registro: $e';
      return false;
    } finally {
      _isLoading = false;
      notifyListeners();
    }
  }

  // Remove registro de alimentação
  Future<bool> removeFeedingRecord(String recordId) async {
    try {
      _isLoading = true;
      notifyListeners();

      _feedingRecords.removeWhere((record) => record.id == recordId);
      await _saveFeedingRecordsToStorage();
      
      return true;
    } catch (e) {
      _errorMessage = 'Erro ao remover registro: $e';
      return false;
    } finally {
      _isLoading = false;
      notifyListeners();
    }
  }

  // Obtém registros de um bebê específico
  List<FeedingRecord> getFeedingRecordsForBaby(String babyId) {
    return _feedingRecords
        .where((record) => record.babyId == babyId)
        .toList();
  }

  // Obtém registros de hoje
  List<FeedingRecord> getTodayFeedingRecords(String babyId) {
    final today = DateTime.now();
    final startOfDay = DateTime(today.year, today.month, today.day);
    final endOfDay = startOfDay.add(const Duration(days: 1));

    return _feedingRecords
        .where((record) => 
            record.babyId == babyId &&
            record.timestamp.isAfter(startOfDay) &&
            record.timestamp.isBefore(endOfDay))
        .toList();
  }

  // Obtém registros dos últimos N dias
  List<FeedingRecord> getRecentFeedingRecords(String babyId, int days) {
    final cutoffDate = DateTime.now().subtract(Duration(days: days));
    
    return _feedingRecords
        .where((record) => 
            record.babyId == babyId &&
            record.timestamp.isAfter(cutoffDate))
        .toList();
  }

  // Gera estatísticas para um período
  FeedingStats getFeedingStats(String babyId, DateTime startDate, DateTime endDate) {
    final records = _feedingRecords
        .where((record) => 
            record.babyId == babyId &&
            record.timestamp.isAfter(startDate) &&
            record.timestamp.isBefore(endDate))
        .toList();

    return FeedingStats.fromRecords(records, startDate, endDate);
  }

  // Obtém estatísticas de hoje
  FeedingStats getTodayStats(String babyId) {
    final today = DateTime.now();
    final startOfDay = DateTime(today.year, today.month, today.day);
    final endOfDay = startOfDay.add(const Duration(days: 1));
    
    return getFeedingStats(babyId, startOfDay, endOfDay);
  }

  // Obtém estatísticas da semana
  FeedingStats getWeekStats(String babyId) {
    final now = DateTime.now();
    final startOfWeek = now.subtract(Duration(days: now.weekday - 1));
    final startOfWeekDay = DateTime(startOfWeek.year, startOfWeek.month, startOfWeek.day);
    
    return getFeedingStats(babyId, startOfWeekDay, now);
  }

  // Obtém último registro de alimentação
  FeedingRecord? getLastFeedingRecord(String babyId) {
    final babyRecords = getFeedingRecordsForBaby(babyId);
    return babyRecords.isNotEmpty ? babyRecords.first : null;
  }

  // Calcula tempo desde a última mamada
  Duration? getTimeSinceLastFeeding(String babyId) {
    final lastRecord = getLastFeedingRecord(babyId);
    if (lastRecord == null) return null;
    
    return DateTime.now().difference(lastRecord.timestamp);
  }

  // Limpa todos os registros
  Future<void> clearAllRecords() async {
    try {
      _feedingRecords.clear();
      await _saveFeedingRecordsToStorage();
      notifyListeners();
    } catch (e) {
      debugPrint('Erro ao limpar registros: $e');
    }
  }

  // Limpa mensagem de erro
  void clearError() {
    _errorMessage = null;
    notifyListeners();
  }
}

