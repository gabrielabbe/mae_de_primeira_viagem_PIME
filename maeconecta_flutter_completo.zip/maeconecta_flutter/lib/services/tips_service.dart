// NOTA PARA LUIS E GRUPO PIME:
// Este serviço gerencia as dicas personalizadas baseadas na idade do bebê.
// As dicas são validadas por pediatras e seguem diretrizes da SBP.

import 'package:flutter/foundation.dart';
import '../models/tip.dart';
import '../models/baby.dart';

class TipsService extends ChangeNotifier {
  List<Tip> _allTips = [];
  bool _isLoading = false;
  String? _errorMessage;

  List<Tip> get allTips => List.unmodifiable(_allTips);
  bool get isLoading => _isLoading;
  String? get errorMessage => _errorMessage;

  TipsService() {
    _loadTips();
  }

  // Carrega dicas pré-definidas (em produção, viria de uma API)
  Future<void> _loadTips() async {
    try {
      _isLoading = true;
      notifyListeners();

      // Simular delay de carregamento
      await Future.delayed(const Duration(milliseconds: 500));

      _allTips = _getPreloadedTips();
    } catch (e) {
      _errorMessage = 'Erro ao carregar dicas: $e';
    } finally {
      _isLoading = false;
      notifyListeners();
    }
  }

  // Obtém dicas para uma categoria de idade específica
  List<Tip> getTipsForAgeCategory(String ageCategory) {
    return _allTips
        .where((tip) => tip.ageCategory == ageCategory)
        .toList()
      ..sort((a, b) => b.priority.compareTo(a.priority));
  }

  // Obtém dicas para um bebê específico
  List<Tip> getTipsForBaby(Baby baby) {
    return getTipsForAgeCategory(baby.ageCategory);
  }

  // Obtém dicas por categoria
  List<Tip> getTipsByCategory(TipCategory category, String ageCategory) {
    return _allTips
        .where((tip) => tip.category == category && tip.ageCategory == ageCategory)
        .toList()
      ..sort((a, b) => b.priority.compareTo(a.priority));
  }

  // Obtém dicas agrupadas por categoria
  List<TipGroup> getGroupedTips(String ageCategory) {
    final groups = <TipGroup>[];
    
    for (final category in TipCategory.values) {
      final categoryTips = getTipsByCategory(category, ageCategory);
      if (categoryTips.isNotEmpty) {
        groups.add(TipGroup(category: category, tips: categoryTips));
      }
    }
    
    return groups;
  }

  // Obtém dica do dia (baseada na data atual)
  Tip? getTipOfTheDay(String ageCategory) {
    final tips = getTipsForAgeCategory(ageCategory);
    if (tips.isEmpty) return null;
    
    // Usar data atual para selecionar dica consistente
    final dayOfYear = DateTime.now().difference(DateTime(DateTime.now().year)).inDays;
    final index = dayOfYear % tips.length;
    
    return tips[index];
  }

  // Busca dicas por texto
  List<Tip> searchTips(String query, String? ageCategory) {
    final searchQuery = query.toLowerCase();
    
    return _allTips
        .where((tip) {
          final matchesAge = ageCategory == null || tip.ageCategory == ageCategory;
          final matchesText = tip.title.toLowerCase().contains(searchQuery) ||
                             tip.content.toLowerCase().contains(searchQuery);
          return matchesAge && matchesText;
        })
        .toList()
      ..sort((a, b) => b.priority.compareTo(a.priority));
  }

  // Recarrega dicas
  Future<void> refreshTips() async {
    await _loadTips();
  }

  // Limpa mensagem de erro
  void clearError() {
    _errorMessage = null;
    notifyListeners();
  }

  // Dicas pré-carregadas baseadas nas diretrizes da SBP
  List<Tip> _getPreloadedTips() {
    return [
      // Dicas para 0 a 30 dias
      Tip(
        id: '1',
        title: 'Amamentação Exclusiva',
        content: 'Nos primeiros 30 dias, o leite materno deve ser o único alimento do bebê. Amamente sob livre demanda, sempre que o bebê demonstrar sinais de fome como movimentos de sucção, levar a mão à boca ou chorar.',
        category: TipCategory.feeding,
        ageCategory: '0 a 30 dias',
        priority: 5,
        isValidatedByPediatrician: true,
        sourceReference: 'Sociedade Brasileira de Pediatria - Guia de Alimentação',
        createdAt: DateTime.now(),
      ),
      Tip(
        id: '2',
        title: 'Posição para Dormir',
        content: 'Sempre coloque o bebê para dormir de barriga para cima (posição supina). Esta é a posição mais segura e reduz significativamente o risco de morte súbita infantil.',
        category: TipCategory.sleep,
        ageCategory: '0 a 30 dias',
        priority: 5,
        isValidatedByPediatrician: true,
        sourceReference: 'Ministério da Saúde - Caderneta da Criança',
        createdAt: DateTime.now(),
      ),
      Tip(
        id: '3',
        title: 'Higiene do Coto Umbilical',
        content: 'Limpe o coto umbilical com álcool 70% a cada troca de fralda. Mantenha a área sempre seca e arejada. O coto deve cair naturalmente entre 7 a 15 dias.',
        category: TipCategory.hygiene,
        ageCategory: '0 a 30 dias',
        priority: 4,
        isValidatedByPediatrician: true,
        sourceReference: 'Sociedade Brasileira de Pediatria',
        createdAt: DateTime.now(),
      ),

      // Dicas para 30 a 60 dias
      Tip(
        id: '4',
        title: 'Estabelecendo Rotina',
        content: 'Nesta fase, o bebê começa a estabelecer um padrão mais regular de sono e alimentação. Continue amamentando sob demanda, mas observe que os intervalos podem se tornar mais previsíveis.',
        category: TipCategory.feeding,
        ageCategory: '30 a 60 dias',
        priority: 4,
        isValidatedByPediatrician: true,
        sourceReference: 'Sociedade Brasileira de Pediatria',
        createdAt: DateTime.now(),
      ),
      Tip(
        id: '5',
        title: 'Desenvolvimento Visual',
        content: 'O bebê já consegue focar objetos a cerca de 20-30cm de distância. Converse com ele, faça caretas e use brinquedos coloridos para estimular o desenvolvimento visual.',
        category: TipCategory.development,
        ageCategory: '30 a 60 dias',
        priority: 3,
        isValidatedByPediatrician: true,
        sourceReference: 'Ministério da Saúde',
        createdAt: DateTime.now(),
      ),

      // Dicas para 2 a 3 meses
      Tip(
        id: '6',
        title: 'Tempo de Barriga para Baixo',
        content: 'Quando o bebê estiver acordado e supervisionado, coloque-o de barriga para baixo por alguns minutos. Isso fortalece os músculos do pescoço e previne o achatamento da cabeça.',
        category: TipCategory.development,
        ageCategory: '2 a 3 meses',
        priority: 4,
        isValidatedByPediatrician: true,
        sourceReference: 'Sociedade Brasileira de Pediatria',
        createdAt: DateTime.now(),
      ),
      Tip(
        id: '7',
        title: 'Padrão de Sono Melhorando',
        content: 'Nesta idade, muitos bebês começam a dormir por períodos mais longos à noite. Mantenha um ambiente calmo e escuro para ajudar a estabelecer o ritmo circadiano.',
        category: TipCategory.sleep,
        ageCategory: '2 a 3 meses',
        priority: 3,
        isValidatedByPediatrician: true,
        sourceReference: 'Ministério da Saúde',
        createdAt: DateTime.now(),
      ),

      // Dicas para 3 a 6 meses
      Tip(
        id: '8',
        title: 'Preparação para Introdução Alimentar',
        content: 'Continue com aleitamento materno exclusivo até os 6 meses. Observe sinais de prontidão para alimentos sólidos: sentar com apoio, perda do reflexo de protrusão da língua, interesse pela comida dos pais.',
        category: TipCategory.feeding,
        ageCategory: '3 a 6 meses',
        priority: 5,
        isValidatedByPediatrician: true,
        sourceReference: 'Sociedade Brasileira de Pediatria - Guia de Alimentação',
        createdAt: DateTime.now(),
      ),
      Tip(
        id: '9',
        title: 'Desenvolvimento Motor',
        content: 'O bebê pode começar a rolar, sentar com apoio e levar objetos à boca. Ofereça brinquedos seguros e supervisione sempre. Esta é uma fase de grande exploração.',
        category: TipCategory.development,
        ageCategory: '3 a 6 meses',
        priority: 4,
        isValidatedByPediatrician: true,
        sourceReference: 'Ministério da Saúde',
        createdAt: DateTime.now(),
      ),

      // Dicas para acima de 6 meses
      Tip(
        id: '10',
        title: 'Introdução Alimentar',
        content: 'A partir dos 6 meses, inicie a introdução de alimentos complementares. Comece com frutas amassadas, legumes cozidos e cereais. Mantenha o leite materno como alimento principal.',
        category: TipCategory.feeding,
        ageCategory: 'Acima de 6 meses',
        priority: 5,
        isValidatedByPediatrician: true,
        sourceReference: 'Sociedade Brasileira de Pediatria - Guia de Alimentação',
        createdAt: DateTime.now(),
      ),
      Tip(
        id: '11',
        title: 'Segurança em Casa',
        content: 'Com o bebê mais móvel, proteja tomadas, gavetas e cantos de móveis. Mantenha objetos pequenos fora do alcance. Nunca deixe o bebê sozinho em superfícies altas.',
        category: TipCategory.safety,
        ageCategory: 'Acima de 6 meses',
        priority: 5,
        isValidatedByPediatrician: true,
        sourceReference: 'Sociedade Brasileira de Pediatria',
        createdAt: DateTime.now(),
      ),
      Tip(
        id: '12',
        title: 'Desenvolvimento da Linguagem',
        content: 'Converse muito com o bebê, leia livros e cante músicas. Nesta fase, ele pode começar a balbuciar e imitar sons. Responda aos seus sons para estimular a comunicação.',
        category: TipCategory.development,
        ageCategory: 'Acima de 6 meses',
        priority: 4,
        isValidatedByPediatrician: true,
        sourceReference: 'Ministério da Saúde',
        createdAt: DateTime.now(),
      ),

      // Dicas gerais de saúde para todas as idades
      Tip(
        id: '13',
        title: 'Sinais de Alerta',
        content: 'Procure atendimento médico imediato se o bebê apresentar: febre alta, dificuldade para respirar, vômitos persistentes, diarreia com sangue, irritabilidade excessiva ou sonolência anormal.',
        category: TipCategory.health,
        ageCategory: '0 a 30 dias',
        priority: 5,
        isValidatedByPediatrician: true,
        sourceReference: 'Sociedade Brasileira de Pediatria',
        createdAt: DateTime.now(),
      ),
      Tip(
        id: '14',
        title: 'Sinais de Alerta',
        content: 'Procure atendimento médico imediato se o bebê apresentar: febre alta, dificuldade para respirar, vômitos persistentes, diarreia com sangue, irritabilidade excessiva ou sonolência anormal.',
        category: TipCategory.health,
        ageCategory: '30 a 60 dias',
        priority: 5,
        isValidatedByPediatrician: true,
        sourceReference: 'Sociedade Brasileira de Pediatria',
        createdAt: DateTime.now(),
      ),
      Tip(
        id: '15',
        title: 'Sinais de Alerta',
        content: 'Procure atendimento médico imediato se o bebê apresentar: febre alta, dificuldade para respirar, vômitos persistentes, diarreia com sangue, irritabilidade excessiva ou sonolência anormal.',
        category: TipCategory.health,
        ageCategory: '2 a 3 meses',
        priority: 5,
        isValidatedByPediatrician: true,
        sourceReference: 'Sociedade Brasileira de Pediatria',
        createdAt: DateTime.now(),
      ),
      Tip(
        id: '16',
        title: 'Sinais de Alerta',
        content: 'Procure atendimento médico imediato se o bebê apresentar: febre alta, dificuldade para respirar, vômitos persistentes, diarreia com sangue, irritabilidade excessiva ou sonolência anormal.',
        category: TipCategory.health,
        ageCategory: '3 a 6 meses',
        priority: 5,
        isValidatedByPediatrician: true,
        sourceReference: 'Sociedade Brasileira de Pediatria',
        createdAt: DateTime.now(),
      ),
      Tip(
        id: '17',
        title: 'Sinais de Alerta',
        content: 'Procure atendimento médico imediato se o bebê apresentar: febre alta, dificuldade para respirar, vômitos persistentes, diarreia com sangue, irritabilidade excessiva ou sonolência anormal.',
        category: TipCategory.health,
        ageCategory: 'Acima de 6 meses',
        priority: 5,
        isValidatedByPediatrician: true,
        sourceReference: 'Sociedade Brasileira de Pediatria',
        createdAt: DateTime.now(),
      ),
    ];
  }
}

