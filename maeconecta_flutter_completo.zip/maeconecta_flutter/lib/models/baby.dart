// NOTA PARA LUIS E GRUPO PIME:
// Este arquivo define o modelo de dados do bebê.
// Inclui cálculos de idade e categorização para as funcionalidades do app.

class Baby {
  final String id;
  final String userId;
  final String name;
  final DateTime birthDate;
  final String? specialNeeds;
  final double? birthWeight;
  final DateTime createdAt;
  final DateTime? updatedAt;

  Baby({
    required this.id,
    required this.userId,
    required this.name,
    required this.birthDate,
    this.specialNeeds,
    this.birthWeight,
    required this.createdAt,
    this.updatedAt,
  });

  // Construtor para criar bebê a partir de JSON
  factory Baby.fromJson(Map<String, dynamic> json) {
    return Baby(
      id: json['id'] as String,
      userId: json['userId'] as String,
      name: json['name'] as String,
      birthDate: DateTime.parse(json['birthDate'] as String),
      specialNeeds: json['specialNeeds'] as String?,
      birthWeight: json['birthWeight']?.toDouble(),
      createdAt: DateTime.parse(json['createdAt'] as String),
      updatedAt: json['updatedAt'] != null 
          ? DateTime.parse(json['updatedAt'] as String)
          : null,
    );
  }

  // Método para converter bebê para JSON
  Map<String, dynamic> toJson() {
    return {
      'id': id,
      'userId': userId,
      'name': name,
      'birthDate': birthDate.toIso8601String(),
      'specialNeeds': specialNeeds,
      'birthWeight': birthWeight,
      'createdAt': createdAt.toIso8601String(),
      'updatedAt': updatedAt?.toIso8601String(),
    };
  }

  // Calcula a idade em meses
  double get ageInMonths {
    final now = DateTime.now();
    final difference = now.difference(birthDate);
    return difference.inDays / 30.4375; // Média de dias por mês
  }

  // Calcula a idade em dias
  int get ageInDays {
    final now = DateTime.now();
    return now.difference(birthDate).inDays;
  }

  // Retorna a categoria de idade para cálculos de amamentação
  String get ageCategory {
    final months = ageInMonths;
    
    if (months <= 1) {
      return "0 a 30 dias";
    } else if (months <= 2) {
      return "30 a 60 dias";
    } else if (months <= 3) {
      return "2 a 3 meses";
    } else if (months <= 6) {
      return "3 a 6 meses";
    } else {
      return "Acima de 6 meses";
    }
  }

  // Verifica se o bebê já pode receber introdução alimentar
  bool get canStartSolidFood {
    return ageInMonths >= 6;
  }

  // Retorna uma descrição amigável da idade
  String get ageFriendlyDescription {
    final days = ageInDays;
    final months = ageInMonths;
    
    if (days < 30) {
      return "$days dias";
    } else if (months < 12) {
      final monthsInt = months.floor();
      final remainingDays = (days - (monthsInt * 30.4375)).round();
      if (remainingDays > 0) {
        return "$monthsInt meses e $remainingDays dias";
      } else {
        return "$monthsInt meses";
      }
    } else {
      final years = (months / 12).floor();
      final remainingMonths = (months % 12).floor();
      if (remainingMonths > 0) {
        return "$years ano${years > 1 ? 's' : ''} e $remainingMonths meses";
      } else {
        return "$years ano${years > 1 ? 's' : ''}";
      }
    }
  }

  // Método para criar cópia com alterações
  Baby copyWith({
    String? id,
    String? userId,
    String? name,
    DateTime? birthDate,
    String? specialNeeds,
    double? birthWeight,
    DateTime? createdAt,
    DateTime? updatedAt,
  }) {
    return Baby(
      id: id ?? this.id,
      userId: userId ?? this.userId,
      name: name ?? this.name,
      birthDate: birthDate ?? this.birthDate,
      specialNeeds: specialNeeds ?? this.specialNeeds,
      birthWeight: birthWeight ?? this.birthWeight,
      createdAt: createdAt ?? this.createdAt,
      updatedAt: updatedAt ?? this.updatedAt,
    );
  }

  // Validação de nome
  static bool isValidName(String name) {
    return name.trim().length >= 2;
  }

  // Validação de data de nascimento
  static bool isValidBirthDate(DateTime birthDate) {
    final now = DateTime.now();
    return birthDate.isBefore(now) && 
           now.difference(birthDate).inDays <= 365 * 2; // Máximo 2 anos
  }

  @override
  String toString() {
    return 'Baby(id: $id, name: $name, ageCategory: $ageCategory)';
  }

  @override
  bool operator ==(Object other) {
    if (identical(this, other)) return true;
    return other is Baby && other.id == id;
  }

  @override
  int get hashCode => id.hashCode;
}

