// NOTA PARA LUIS E GRUPO PIME:
// Este arquivo define o modelo para dicas personalizadas.
// As dicas são baseadas na idade do bebê e validadas por pediatras.

enum TipCategory {
  feeding,
  sleep,
  hygiene,
  development,
  health,
  safety,
}

class Tip {
  final String id;
  final String title;
  final String content;
  final TipCategory category;
  final String ageCategory; // "0 a 30 dias", "30 a 60 dias", etc.
  final int priority; // 1-5, sendo 5 mais importante
  final bool isValidatedByPediatrician;
  final String? sourceReference;
  final DateTime createdAt;
  final DateTime? updatedAt;

  Tip({
    required this.id,
    required this.title,
    required this.content,
    required this.category,
    required this.ageCategory,
    required this.priority,
    required this.isValidatedByPediatrician,
    this.sourceReference,
    required this.createdAt,
    this.updatedAt,
  });

  // Construtor para criar dica a partir de JSON
  factory Tip.fromJson(Map<String, dynamic> json) {
    return Tip(
      id: json['id'] as String,
      title: json['title'] as String,
      content: json['content'] as String,
      category: TipCategory.values.firstWhere(
        (e) => e.toString() == 'TipCategory.${json['category']}',
      ),
      ageCategory: json['ageCategory'] as String,
      priority: json['priority'] as int,
      isValidatedByPediatrician: json['isValidatedByPediatrician'] as bool,
      sourceReference: json['sourceReference'] as String?,
      createdAt: DateTime.parse(json['createdAt'] as String),
      updatedAt: json['updatedAt'] != null 
          ? DateTime.parse(json['updatedAt'] as String)
          : null,
    );
  }

  // Método para converter dica para JSON
  Map<String, dynamic> toJson() {
    return {
      'id': id,
      'title': title,
      'content': content,
      'category': category.toString().split('.').last,
      'ageCategory': ageCategory,
      'priority': priority,
      'isValidatedByPediatrician': isValidatedByPediatrician,
      'sourceReference': sourceReference,
      'createdAt': createdAt.toIso8601String(),
      'updatedAt': updatedAt?.toIso8601String(),
    };
  }

  // Retorna descrição amigável da categoria
  String get categoryDescription {
    switch (category) {
      case TipCategory.feeding:
        return 'Alimentação';
      case TipCategory.sleep:
        return 'Sono';
      case TipCategory.hygiene:
        return 'Higiene';
      case TipCategory.development:
        return 'Desenvolvimento';
      case TipCategory.health:
        return 'Saúde';
      case TipCategory.safety:
        return 'Segurança';
    }
  }

  // Retorna ícone para a categoria
  String get categoryIcon {
    switch (category) {
      case TipCategory.feeding:
        return '🍼';
      case TipCategory.sleep:
        return '😴';
      case TipCategory.hygiene:
        return '🛁';
      case TipCategory.development:
        return '👶';
      case TipCategory.health:
        return '🏥';
      case TipCategory.safety:
        return '🛡️';
    }
  }

  // Retorna cor para a categoria
  String get categoryColor {
    switch (category) {
      case TipCategory.feeding:
        return '#4CAF50'; // Verde
      case TipCategory.sleep:
        return '#3F51B5'; // Azul
      case TipCategory.hygiene:
        return '#00BCD4'; // Ciano
      case TipCategory.development:
        return '#FF9800'; // Laranja
      case TipCategory.health:
        return '#F44336'; // Vermelho
      case TipCategory.safety:
        return '#9C27B0'; // Roxo
    }
  }

  // Método para criar cópia com alterações
  Tip copyWith({
    String? id,
    String? title,
    String? content,
    TipCategory? category,
    String? ageCategory,
    int? priority,
    bool? isValidatedByPediatrician,
    String? sourceReference,
    DateTime? createdAt,
    DateTime? updatedAt,
  }) {
    return Tip(
      id: id ?? this.id,
      title: title ?? this.title,
      content: content ?? this.content,
      category: category ?? this.category,
      ageCategory: ageCategory ?? this.ageCategory,
      priority: priority ?? this.priority,
      isValidatedByPediatrician: isValidatedByPediatrician ?? this.isValidatedByPediatrician,
      sourceReference: sourceReference ?? this.sourceReference,
      createdAt: createdAt ?? this.createdAt,
      updatedAt: updatedAt ?? this.updatedAt,
    );
  }

  @override
  String toString() {
    return 'Tip(id: $id, title: $title, category: $categoryDescription)';
  }

  @override
  bool operator ==(Object other) {
    if (identical(this, other)) return true;
    return other is Tip && other.id == id;
  }

  @override
  int get hashCode => id.hashCode;
}

// Classe para agrupar dicas por categoria
class TipGroup {
  final TipCategory category;
  final List<Tip> tips;

  TipGroup({
    required this.category,
    required this.tips,
  });

  String get categoryDescription {
    switch (category) {
      case TipCategory.feeding:
        return 'Alimentação';
      case TipCategory.sleep:
        return 'Sono';
      case TipCategory.hygiene:
        return 'Higiene';
      case TipCategory.development:
        return 'Desenvolvimento';
      case TipCategory.health:
        return 'Saúde';
      case TipCategory.safety:
        return 'Segurança';
    }
  }

  // Ordena dicas por prioridade (maior primeiro)
  List<Tip> get sortedTips {
    final sorted = List<Tip>.from(tips);
    sorted.sort((a, b) => b.priority.compareTo(a.priority));
    return sorted;
  }
}

