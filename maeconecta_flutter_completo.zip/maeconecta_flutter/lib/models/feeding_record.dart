// NOTA PARA LUIS E GRUPO PIME:
// Este arquivo define o modelo para registros de mamadas.
// Permite acompanhar o histórico de alimentação do bebê.

enum FeedingType {
  breastfeeding,
  bottle,
  mixed,
}

class FeedingRecord {
  final String id;
  final String babyId;
  final DateTime timestamp;
  final FeedingType type;
  final int? volumeMl; // Para mamadeira
  final int? durationMinutes; // Para amamentação
  final String? notes;
  final DateTime createdAt;

  FeedingRecord({
    required this.id,
    required this.babyId,
    required this.timestamp,
    required this.type,
    this.volumeMl,
    this.durationMinutes,
    this.notes,
    required this.createdAt,
  });

  // Construtor para criar registro a partir de JSON
  factory FeedingRecord.fromJson(Map<String, dynamic> json) {
    return FeedingRecord(
      id: json['id'] as String,
      babyId: json['babyId'] as String,
      timestamp: DateTime.parse(json['timestamp'] as String),
      type: FeedingType.values.firstWhere(
        (e) => e.toString() == 'FeedingType.${json['type']}',
      ),
      volumeMl: json['volumeMl'] as int?,
      durationMinutes: json['durationMinutes'] as int?,
      notes: json['notes'] as String?,
      createdAt: DateTime.parse(json['createdAt'] as String),
    );
  }

  // Método para converter registro para JSON
  Map<String, dynamic> toJson() {
    return {
      'id': id,
      'babyId': babyId,
      'timestamp': timestamp.toIso8601String(),
      'type': type.toString().split('.').last,
      'volumeMl': volumeMl,
      'durationMinutes': durationMinutes,
      'notes': notes,
      'createdAt': createdAt.toIso8601String(),
    };
  }

  // Retorna descrição amigável do tipo de alimentação
  String get typeDescription {
    switch (type) {
      case FeedingType.breastfeeding:
        return 'Amamentação';
      case FeedingType.bottle:
        return 'Mamadeira';
      case FeedingType.mixed:
        return 'Misto';
    }
  }

  // Retorna descrição completa do registro
  String get description {
    String base = typeDescription;
    
    if (type == FeedingType.bottle && volumeMl != null) {
      base += ' - ${volumeMl}ml';
    }
    
    if (type == FeedingType.breastfeeding && durationMinutes != null) {
      base += ' - ${durationMinutes}min';
    }
    
    return base;
  }

  // Método para criar cópia com alterações
  FeedingRecord copyWith({
    String? id,
    String? babyId,
    DateTime? timestamp,
    FeedingType? type,
    int? volumeMl,
    int? durationMinutes,
    String? notes,
    DateTime? createdAt,
  }) {
    return FeedingRecord(
      id: id ?? this.id,
      babyId: babyId ?? this.babyId,
      timestamp: timestamp ?? this.timestamp,
      type: type ?? this.type,
      volumeMl: volumeMl ?? this.volumeMl,
      durationMinutes: durationMinutes ?? this.durationMinutes,
      notes: notes ?? this.notes,
      createdAt: createdAt ?? this.createdAt,
    );
  }

  @override
  String toString() {
    return 'FeedingRecord(id: $id, type: $typeDescription, timestamp: $timestamp)';
  }

  @override
  bool operator ==(Object other) {
    if (identical(this, other)) return true;
    return other is FeedingRecord && other.id == id;
  }

  @override
  int get hashCode => id.hashCode;
}

// Classe para estatísticas de alimentação
class FeedingStats {
  final int totalFeedings;
  final int totalVolumeMl;
  final int averageVolumeMl;
  final int totalDurationMinutes;
  final int averageDurationMinutes;
  final DateTime periodStart;
  final DateTime periodEnd;

  FeedingStats({
    required this.totalFeedings,
    required this.totalVolumeMl,
    required this.averageVolumeMl,
    required this.totalDurationMinutes,
    required this.averageDurationMinutes,
    required this.periodStart,
    required this.periodEnd,
  });

  // Calcula estatísticas a partir de uma lista de registros
  factory FeedingStats.fromRecords(
    List<FeedingRecord> records,
    DateTime periodStart,
    DateTime periodEnd,
  ) {
    final filteredRecords = records.where((record) =>
        record.timestamp.isAfter(periodStart) &&
        record.timestamp.isBefore(periodEnd)).toList();

    final totalFeedings = filteredRecords.length;
    final totalVolumeMl = filteredRecords
        .where((r) => r.volumeMl != null)
        .fold<int>(0, (sum, r) => sum + r.volumeMl!);
    final totalDurationMinutes = filteredRecords
        .where((r) => r.durationMinutes != null)
        .fold<int>(0, (sum, r) => sum + r.durationMinutes!);

    final volumeRecords = filteredRecords.where((r) => r.volumeMl != null).length;
    final durationRecords = filteredRecords.where((r) => r.durationMinutes != null).length;

    return FeedingStats(
      totalFeedings: totalFeedings,
      totalVolumeMl: totalVolumeMl,
      averageVolumeMl: volumeRecords > 0 ? (totalVolumeMl / volumeRecords).round() : 0,
      totalDurationMinutes: totalDurationMinutes,
      averageDurationMinutes: durationRecords > 0 ? (totalDurationMinutes / durationRecords).round() : 0,
      periodStart: periodStart,
      periodEnd: periodEnd,
    );
  }
}

