// NOTA PARA LUIS E GRUPO PIME:
// Esta tela exibe dicas personalizadas baseadas na idade do bebê.
// As dicas são organizadas por categorias e validadas por pediatras.

import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'package:go_router/go_router.dart';
import '../services/baby_service.dart';
import '../services/tips_service.dart';
import '../models/tip.dart';

class TipsScreen extends StatefulWidget {
  const TipsScreen({super.key});

  @override
  State<TipsScreen> createState() => _TipsScreenState();
}

class _TipsScreenState extends State<TipsScreen>
    with SingleTickerProviderStateMixin {
  late TabController _tabController;
  final _searchController = TextEditingController();
  String _searchQuery = '';
  TipCategory? _selectedCategory;

  @override
  void initState() {
    super.initState();
    _tabController = TabController(length: 2, vsync: this);
  }

  @override
  void dispose() {
    _tabController.dispose();
    _searchController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Dicas Personalizadas'),
        leading: IconButton(
          icon: const Icon(Icons.arrow_back),
          onPressed: () => context.go('/home'),
        ),
        bottom: TabBar(
          controller: _tabController,
          tabs: const [
            Tab(text: 'Por Categoria', icon: Icon(Icons.category)),
            Tab(text: 'Buscar', icon: Icon(Icons.search)),
          ],
        ),
      ),
      body: Consumer2<BabyService, TipsService>(
        builder: (context, babyService, tipsService, child) {
          if (!babyService.hasBaby) {
            return _buildNoBabyState();
          }

          if (tipsService.isLoading) {
            return const Center(child: CircularProgressIndicator());
          }

          return TabBarView(
            controller: _tabController,
            children: [
              _buildCategoryView(babyService, tipsService),
              _buildSearchView(babyService, tipsService),
            ],
          );
        },
      ),
    );
  }

  Widget _buildNoBabyState() {
    return Center(
      child: Padding(
        padding: const EdgeInsets.all(24),
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Icon(
              Icons.baby_changing_station,
              size: 64,
              color: Colors.grey[400],
            ),
            const SizedBox(height: 16),
            Text(
              'Nenhum bebê cadastrado',
              style: Theme.of(context).textTheme.titleLarge?.copyWith(
                fontWeight: FontWeight.bold,
              ),
            ),
            const SizedBox(height: 8),
            Text(
              'Para ver dicas personalizadas, primeiro cadastre as informações do seu bebê',
              style: Theme.of(context).textTheme.bodyMedium?.copyWith(
                color: Colors.grey[600],
              ),
              textAlign: TextAlign.center,
            ),
            const SizedBox(height: 24),
            ElevatedButton(
              onPressed: () => context.go('/baby-profile'),
              child: const Text('Cadastrar Bebê'),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildCategoryView(BabyService babyService, TipsService tipsService) {
    final baby = babyService.currentBaby!;
    final tipGroups = tipsService.getGroupedTips(baby.ageCategory);

    return RefreshIndicator(
      onRefresh: () => tipsService.refreshTips(),
      child: SingleChildScrollView(
        padding: const EdgeInsets.all(16),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            // Informações do bebê
            _buildBabyInfoCard(baby),
            
            const SizedBox(height: 16),
            
            // Dica do dia
            _buildTipOfTheDayCard(tipsService, baby),
            
            const SizedBox(height: 16),
            
            // Categorias de dicas
            if (tipGroups.isEmpty) ...[
              _buildNoTipsState(),
            ] else ...[
              Text(
                'Dicas por Categoria',
                style: Theme.of(context).textTheme.titleMedium?.copyWith(
                  fontWeight: FontWeight.bold,
                ),
              ),
              const SizedBox(height: 12),
              ...tipGroups.map((group) => _buildCategoryCard(group)),
            ],
          ],
        ),
      ),
    );
  }

  Widget _buildSearchView(BabyService babyService, TipsService tipsService) {
    final baby = babyService.currentBaby!;
    final searchResults = _searchQuery.isEmpty
        ? <Tip>[]
        : tipsService.searchTips(_searchQuery, baby.ageCategory);

    return Column(
      children: [
        // Barra de busca
        Padding(
          padding: const EdgeInsets.all(16),
          child: Column(
            children: [
              TextField(
                controller: _searchController,
                decoration: InputDecoration(
                  hintText: 'Buscar dicas...',
                  prefixIcon: const Icon(Icons.search),
                  suffixIcon: _searchQuery.isNotEmpty
                      ? IconButton(
                          icon: const Icon(Icons.clear),
                          onPressed: () {
                            _searchController.clear();
                            setState(() {
                              _searchQuery = '';
                            });
                          },
                        )
                      : null,
                ),
                onChanged: (value) {
                  setState(() {
                    _searchQuery = value;
                  });
                },
              ),
              
              const SizedBox(height: 12),
              
              // Filtro por categoria
              SingleChildScrollView(
                scrollDirection: Axis.horizontal,
                child: Row(
                  children: [
                    FilterChip(
                      label: const Text('Todas'),
                      selected: _selectedCategory == null,
                      onSelected: (selected) {
                        setState(() {
                          _selectedCategory = null;
                        });
                      },
                    ),
                    const SizedBox(width: 8),
                    ...TipCategory.values.map((category) {
                      return Padding(
                        padding: const EdgeInsets.only(right: 8),
                        child: FilterChip(
                          label: Text(_getCategoryName(category)),
                          selected: _selectedCategory == category,
                          onSelected: (selected) {
                            setState(() {
                              _selectedCategory = selected ? category : null;
                            });
                          },
                        ),
                      );
                    }),
                  ],
                ),
              ),
            ],
          ),
        ),
        
        // Resultados da busca
        Expanded(
          child: _searchQuery.isEmpty
              ? _buildSearchEmptyState()
              : _buildSearchResults(searchResults),
        ),
      ],
    );
  }

  Widget _buildBabyInfoCard(baby) {
    return Card(
      child: Padding(
        padding: const EdgeInsets.all(16),
        child: Row(
          children: [
            CircleAvatar(
              radius: 20,
              backgroundColor: Theme.of(context).colorScheme.primary,
              child: Text(
                baby.name.substring(0, 1).toUpperCase(),
                style: const TextStyle(
                  fontSize: 16,
                  fontWeight: FontWeight.bold,
                  color: Colors.white,
                ),
              ),
            ),
            const SizedBox(width: 12),
            Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(
                    'Dicas para ${baby.name}',
                    style: Theme.of(context).textTheme.titleMedium?.copyWith(
                      fontWeight: FontWeight.bold,
                    ),
                  ),
                  Text(
                    '${baby.ageFriendlyDescription} • ${baby.ageCategory}',
                    style: Theme.of(context).textTheme.bodySmall?.copyWith(
                      color: Colors.grey[600],
                    ),
                  ),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildTipOfTheDayCard(TipsService tipsService, baby) {
    final tipOfTheDay = tipsService.getTipOfTheDay(baby.ageCategory);
    
    if (tipOfTheDay == null) return const SizedBox.shrink();

    return Card(
      color: Theme.of(context).colorScheme.primary.withOpacity(0.05),
      child: Padding(
        padding: const EdgeInsets.all(16),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Row(
              children: [
                Container(
                  padding: const EdgeInsets.all(8),
                  decoration: BoxDecoration(
                    color: Theme.of(context).colorScheme.primary,
                    borderRadius: BorderRadius.circular(8),
                  ),
                  child: const Icon(
                    Icons.star,
                    color: Colors.white,
                    size: 20,
                  ),
                ),
                const SizedBox(width: 12),
                Expanded(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(
                        'Dica do Dia',
                        style: Theme.of(context).textTheme.titleMedium?.copyWith(
                          fontWeight: FontWeight.bold,
                          color: Theme.of(context).colorScheme.primary,
                        ),
                      ),
                      Text(
                        tipOfTheDay.categoryDescription,
                        style: Theme.of(context).textTheme.bodySmall?.copyWith(
                          color: Colors.grey[600],
                        ),
                      ),
                    ],
                  ),
                ),
              ],
            ),
            
            const SizedBox(height: 12),
            
            Text(
              tipOfTheDay.title,
              style: Theme.of(context).textTheme.titleSmall?.copyWith(
                fontWeight: FontWeight.bold,
              ),
            ),
            
            const SizedBox(height: 8),
            
            Text(
              tipOfTheDay.content,
              style: Theme.of(context).textTheme.bodyMedium,
            ),
            
            if (tipOfTheDay.isValidatedByPediatrician) ...[
              const SizedBox(height: 8),
              Row(
                children: [
                  Icon(
                    Icons.verified,
                    size: 16,
                    color: Colors.green[600],
                  ),
                  const SizedBox(width: 4),
                  Text(
                    'Validado por pediatra',
                    style: TextStyle(
                      fontSize: 12,
                      color: Colors.green[600],
                      fontWeight: FontWeight.w500,
                    ),
                  ),
                ],
              ),
            ],
          ],
        ),
      ),
    );
  }

  Widget _buildCategoryCard(TipGroup group) {
    return Card(
      margin: const EdgeInsets.only(bottom: 12),
      child: ExpansionTile(
        leading: Container(
          padding: const EdgeInsets.all(8),
          decoration: BoxDecoration(
            color: _getCategoryColor(group.category).withOpacity(0.1),
            borderRadius: BorderRadius.circular(8),
          ),
          child: Text(
            _getCategoryIcon(group.category),
            style: const TextStyle(fontSize: 20),
          ),
        ),
        title: Text(
          group.categoryDescription,
          style: const TextStyle(fontWeight: FontWeight.bold),
        ),
        subtitle: Text('${group.tips.length} dicas disponíveis'),
        children: group.sortedTips.map((tip) => _buildTipItem(tip)).toList(),
      ),
    );
  }

  Widget _buildTipItem(Tip tip) {
    return Container(
      margin: const EdgeInsets.symmetric(horizontal: 16, vertical: 4),
      padding: const EdgeInsets.all(12),
      decoration: BoxDecoration(
        color: Colors.grey[50],
        borderRadius: BorderRadius.circular(8),
        border: Border.all(color: Colors.grey[200]!),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            children: [
              Expanded(
                child: Text(
                  tip.title,
                  style: const TextStyle(
                    fontWeight: FontWeight.bold,
                    fontSize: 14,
                  ),
                ),
              ),
              if (tip.isValidatedByPediatrician)
                Icon(
                  Icons.verified,
                  size: 16,
                  color: Colors.green[600],
                ),
            ],
          ),
          
          const SizedBox(height: 8),
          
          Text(
            tip.content,
            style: const TextStyle(fontSize: 13),
          ),
          
          if (tip.sourceReference != null) ...[
            const SizedBox(height: 8),
            Text(
              'Fonte: ${tip.sourceReference}',
              style: TextStyle(
                fontSize: 11,
                color: Colors.grey[600],
                fontStyle: FontStyle.italic,
              ),
            ),
          ],
        ],
      ),
    );
  }

  Widget _buildSearchEmptyState() {
    return Center(
      child: Padding(
        padding: const EdgeInsets.all(24),
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Icon(
              Icons.search,
              size: 64,
              color: Colors.grey[400],
            ),
            const SizedBox(height: 16),
            Text(
              'Busque por dicas',
              style: Theme.of(context).textTheme.titleMedium?.copyWith(
                fontWeight: FontWeight.bold,
              ),
            ),
            const SizedBox(height: 8),
            Text(
              'Digite palavras-chave para encontrar dicas específicas',
              style: Theme.of(context).textTheme.bodyMedium?.copyWith(
                color: Colors.grey[600],
              ),
              textAlign: TextAlign.center,
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildSearchResults(List<Tip> results) {
    if (results.isEmpty) {
      return Center(
        child: Padding(
          padding: const EdgeInsets.all(24),
          child: Column(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              Icon(
                Icons.search_off,
                size: 64,
                color: Colors.grey[400],
              ),
              const SizedBox(height: 16),
              Text(
                'Nenhuma dica encontrada',
                style: Theme.of(context).textTheme.titleMedium?.copyWith(
                  fontWeight: FontWeight.bold,
                ),
              ),
              const SizedBox(height: 8),
              Text(
                'Tente usar outras palavras-chave',
                style: Theme.of(context).textTheme.bodyMedium?.copyWith(
                  color: Colors.grey[600],
                ),
              ),
            ],
          ),
        ),
      );
    }

    // Filtrar por categoria se selecionada
    final filteredResults = _selectedCategory != null
        ? results.where((tip) => tip.category == _selectedCategory).toList()
        : results;

    return ListView.builder(
      padding: const EdgeInsets.all(16),
      itemCount: filteredResults.length,
      itemBuilder: (context, index) {
        final tip = filteredResults[index];
        return Card(
          margin: const EdgeInsets.only(bottom: 12),
          child: Padding(
            padding: const EdgeInsets.all(16),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Row(
                  children: [
                    Container(
                      padding: const EdgeInsets.all(6),
                      decoration: BoxDecoration(
                        color: _getCategoryColor(tip.category).withOpacity(0.1),
                        borderRadius: BorderRadius.circular(6),
                      ),
                      child: Text(
                        _getCategoryIcon(tip.category),
                        style: const TextStyle(fontSize: 16),
                      ),
                    ),
                    const SizedBox(width: 8),
                    Expanded(
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Text(
                            tip.title,
                            style: const TextStyle(
                              fontWeight: FontWeight.bold,
                              fontSize: 14,
                            ),
                          ),
                          Text(
                            tip.categoryDescription,
                            style: TextStyle(
                              fontSize: 12,
                              color: Colors.grey[600],
                            ),
                          ),
                        ],
                      ),
                    ),
                    if (tip.isValidatedByPediatrician)
                      Icon(
                        Icons.verified,
                        size: 16,
                        color: Colors.green[600],
                      ),
                  ],
                ),
                
                const SizedBox(height: 12),
                
                Text(
                  tip.content,
                  style: const TextStyle(fontSize: 13),
                ),
                
                if (tip.sourceReference != null) ...[
                  const SizedBox(height: 8),
                  Text(
                    'Fonte: ${tip.sourceReference}',
                    style: TextStyle(
                      fontSize: 11,
                      color: Colors.grey[600],
                      fontStyle: FontStyle.italic,
                    ),
                  ),
                ],
              ],
            ),
          ),
        );
      },
    );
  }

  Widget _buildNoTipsState() {
    return Center(
      child: Padding(
        padding: const EdgeInsets.all(24),
        child: Column(
          children: [
            Icon(
              Icons.lightbulb_outline,
              size: 64,
              color: Colors.grey[400],
            ),
            const SizedBox(height: 16),
            Text(
              'Nenhuma dica disponível',
              style: Theme.of(context).textTheme.titleMedium?.copyWith(
                fontWeight: FontWeight.bold,
              ),
            ),
            const SizedBox(height: 8),
            Text(
              'Não encontramos dicas para esta faixa etária no momento',
              style: Theme.of(context).textTheme.bodyMedium?.copyWith(
                color: Colors.grey[600],
              ),
              textAlign: TextAlign.center,
            ),
          ],
        ),
      ),
    );
  }

  String _getCategoryName(TipCategory category) {
    switch (category) {
      case TipCategory.feeding:
        return 'Alimentação';
      case TipCategory.sleep:
        return 'Sono';
      case TipCategory.hygiene:
        return 'Higiene';
      case TipCategory.development:
        return 'Desenvolvimento';
      case TipCategory.health:
        return 'Saúde';
      case TipCategory.safety:
        return 'Segurança';
    }
  }

  String _getCategoryIcon(TipCategory category) {
    switch (category) {
      case TipCategory.feeding:
        return '🍼';
      case TipCategory.sleep:
        return '😴';
      case TipCategory.hygiene:
        return '🛁';
      case TipCategory.development:
        return '👶';
      case TipCategory.health:
        return '🏥';
      case TipCategory.safety:
        return '🛡️';
    }
  }

  Color _getCategoryColor(TipCategory category) {
    switch (category) {
      case TipCategory.feeding:
        return Colors.green;
      case TipCategory.sleep:
        return Colors.blue;
      case TipCategory.hygiene:
        return Colors.cyan;
      case TipCategory.development:
        return Colors.orange;
      case TipCategory.health:
        return Colors.red;
      case TipCategory.safety:
        return Colors.purple;
    }
  }
}

