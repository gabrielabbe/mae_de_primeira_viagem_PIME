// NOTA PARA LUIS E GRUPO PIME:
// Esta tela permite ao usuário gerenciar seu perfil, configurações
// e acessar informações sobre o aplicativo.

import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'package:go_router/go_router.dart';
import '../services/auth_service.dart';
import '../services/baby_service.dart';
import '../services/notification_service.dart';

class ProfileScreen extends StatefulWidget {
  const ProfileScreen({super.key});

  @override
  State<ProfileScreen> createState() => _ProfileScreenState();
}

class _ProfileScreenState extends State<ProfileScreen> {
  bool _notificationsEnabled = true;
  bool _dailyTipsEnabled = true;
  bool _feedingRemindersEnabled = true;

  @override
  void initState() {
    super.initState();
    _loadNotificationSettings();
  }

  Future<void> _loadNotificationSettings() async {
    final enabled = await NotificationService.areNotificationsEnabled();
    setState(() {
      _notificationsEnabled = enabled;
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Perfil'),
        leading: IconButton(
          icon: const Icon(Icons.arrow_back),
          onPressed: () => context.go('/home'),
        ),
      ),
      body: Consumer2<AuthService, BabyService>(
        builder: (context, authService, babyService, child) {
          final user = authService.currentUser;
          final baby = babyService.currentBaby;

          return SingleChildScrollView(
            padding: const EdgeInsets.all(16),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                // Informações do usuário
                _buildUserInfoCard(user),
                
                const SizedBox(height: 16),
                
                // Informações do bebê
                if (baby != null) ...[
                  _buildBabyInfoCard(baby),
                  const SizedBox(height: 16),
                ],
                
                // Configurações
                _buildSettingsSection(),
                
                const SizedBox(height: 16),
                
                // Sobre o aplicativo
                _buildAboutSection(),
                
                const SizedBox(height: 16),
                
                // Ações
                _buildActionsSection(authService, babyService),
              ],
            ),
          );
        },
      ),
    );
  }

  Widget _buildUserInfoCard(user) {
    return Card(
      child: Padding(
        padding: const EdgeInsets.all(16),
        child: Column(
          children: [
            Row(
              children: [
                CircleAvatar(
                  radius: 30,
                  backgroundColor: Theme.of(context).colorScheme.primary,
                  backgroundImage: user?.photoUrl != null 
                      ? NetworkImage(user!.photoUrl!) 
                      : null,
                  child: user?.photoUrl == null
                      ? Text(
                          user?.name.substring(0, 1).toUpperCase() ?? 'U',
                          style: const TextStyle(
                            fontSize: 24,
                            fontWeight: FontWeight.bold,
                            color: Colors.white,
                          ),
                        )
                      : null,
                ),
                const SizedBox(width: 16),
                Expanded(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(
                        user?.name ?? 'Usuário',
                        style: Theme.of(context).textTheme.titleLarge?.copyWith(
                          fontWeight: FontWeight.bold,
                        ),
                      ),
                      const SizedBox(height: 4),
                      Text(
                        user?.email ?? '',
                        style: Theme.of(context).textTheme.bodyMedium?.copyWith(
                          color: Colors.grey[600],
                        ),
                      ),
                      const SizedBox(height: 4),
                      if (user?.createdAt != null) ...[
                        Text(
                          'Membro desde ${_formatDate(user!.createdAt)}',
                          style: Theme.of(context).textTheme.bodySmall?.copyWith(
                            color: Colors.grey[500],
                          ),
                        ),
                      ],
                    ],
                  ),
                ),
                IconButton(
                  icon: const Icon(Icons.edit),
                  onPressed: () => _showEditProfileDialog(user),
                ),
              ],
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildBabyInfoCard(baby) {
    return Card(
      child: Padding(
        padding: const EdgeInsets.all(16),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Row(
              children: [
                Icon(
                  Icons.baby_changing_station,
                  color: Theme.of(context).colorScheme.primary,
                  size: 24,
                ),
                const SizedBox(width: 8),
                Text(
                  'Informações do Bebê',
                  style: Theme.of(context).textTheme.titleMedium?.copyWith(
                    fontWeight: FontWeight.bold,
                  ),
                ),
                const Spacer(),
                TextButton(
                  onPressed: () => context.go('/baby-profile'),
                  child: const Text('Editar'),
                ),
              ],
            ),
            
            const SizedBox(height: 12),
            
            Row(
              children: [
                CircleAvatar(
                  radius: 20,
                  backgroundColor: Theme.of(context).colorScheme.primary.withOpacity(0.1),
                  child: Text(
                    baby.name.substring(0, 1).toUpperCase(),
                    style: TextStyle(
                      fontSize: 16,
                      fontWeight: FontWeight.bold,
                      color: Theme.of(context).colorScheme.primary,
                    ),
                  ),
                ),
                const SizedBox(width: 12),
                Expanded(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(
                        baby.name,
                        style: const TextStyle(
                          fontWeight: FontWeight.w600,
                          fontSize: 16,
                        ),
                      ),
                      Text(
                        baby.ageFriendlyDescription,
                        style: TextStyle(
                          color: Colors.grey[600],
                          fontSize: 14,
                        ),
                      ),
                    ],
                  ),
                ),
                Container(
                  padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 4),
                  decoration: BoxDecoration(
                    color: Theme.of(context).colorScheme.primary.withOpacity(0.1),
                    borderRadius: BorderRadius.circular(12),
                  ),
                  child: Text(
                    baby.ageCategory,
                    style: TextStyle(
                      fontSize: 12,
                      color: Theme.of(context).colorScheme.primary,
                      fontWeight: FontWeight.w500,
                    ),
                  ),
                ),
              ],
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildSettingsSection() {
    return Card(
      child: Padding(
        padding: const EdgeInsets.all(16),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Row(
              children: [
                Icon(
                  Icons.settings,
                  color: Theme.of(context).colorScheme.primary,
                  size: 24,
                ),
                const SizedBox(width: 8),
                Text(
                  'Configurações',
                  style: Theme.of(context).textTheme.titleMedium?.copyWith(
                    fontWeight: FontWeight.bold,
                  ),
                ),
              ],
            ),
            
            const SizedBox(height: 16),
            
            // Notificações gerais
            SwitchListTile(
              title: const Text('Notificações'),
              subtitle: const Text('Receber notificações do aplicativo'),
              value: _notificationsEnabled,
              onChanged: (value) async {
                await NotificationService.setNotificationsEnabled(value);
                setState(() {
                  _notificationsEnabled = value;
                });
              },
              secondary: const Icon(Icons.notifications),
            ),
            
            // Dicas diárias
            SwitchListTile(
              title: const Text('Dicas Diárias'),
              subtitle: const Text('Receber uma dica personalizada todo dia'),
              value: _dailyTipsEnabled && _notificationsEnabled,
              onChanged: _notificationsEnabled ? (value) {
                setState(() {
                  _dailyTipsEnabled = value;
                });
                if (value) {
                  NotificationService.scheduleDailyTip();
                }
              } : null,
              secondary: const Icon(Icons.lightbulb),
            ),
            
            // Lembretes de mamadas
            SwitchListTile(
              title: const Text('Lembretes de Mamadas'),
              subtitle: const Text('Receber lembretes baseados no padrão do bebê'),
              value: _feedingRemindersEnabled && _notificationsEnabled,
              onChanged: _notificationsEnabled ? (value) {
                setState(() {
                  _feedingRemindersEnabled = value;
                });
              } : null,
              secondary: const Icon(Icons.restaurant),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildAboutSection() {
    return Card(
      child: Padding(
        padding: const EdgeInsets.all(16),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Row(
              children: [
                Icon(
                  Icons.info,
                  color: Theme.of(context).colorScheme.primary,
                  size: 24,
                ),
                const SizedBox(width: 8),
                Text(
                  'Sobre o MãeConecta',
                  style: Theme.of(context).textTheme.titleMedium?.copyWith(
                    fontWeight: FontWeight.bold,
                  ),
                ),
              ],
            ),
            
            const SizedBox(height: 16),
            
            ListTile(
              leading: const Icon(Icons.info_outline),
              title: const Text('Versão do App'),
              subtitle: const Text('1.0.0'),
              onTap: () => _showVersionInfo(),
            ),
            
            ListTile(
              leading: const Icon(Icons.description),
              title: const Text('Termos de Uso'),
              onTap: () => _showTermsOfService(),
            ),
            
            ListTile(
              leading: const Icon(Icons.privacy_tip),
              title: const Text('Política de Privacidade'),
              onTap: () => _showPrivacyPolicy(),
            ),
            
            ListTile(
              leading: const Icon(Icons.help),
              title: const Text('Ajuda e Suporte'),
              onTap: () => _showHelpDialog(),
            ),
            
            ListTile(
              leading: const Icon(Icons.star),
              title: const Text('Avaliar o App'),
              onTap: () => _rateApp(),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildActionsSection(AuthService authService, BabyService babyService) {
    return Card(
      child: Padding(
        padding: const EdgeInsets.all(16),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Row(
              children: [
                Icon(
                  Icons.admin_panel_settings,
                  color: Theme.of(context).colorScheme.primary,
                  size: 24,
                ),
                const SizedBox(width: 8),
                Text(
                  'Ações',
                  style: Theme.of(context).textTheme.titleMedium?.copyWith(
                    fontWeight: FontWeight.bold,
                  ),
                ),
              ],
            ),
            
            const SizedBox(height: 16),
            
            ListTile(
              leading: const Icon(Icons.backup),
              title: const Text('Exportar Dados'),
              subtitle: const Text('Fazer backup dos seus dados'),
              onTap: () => _exportData(),
            ),
            
            ListTile(
              leading: Icon(Icons.delete_forever, color: Colors.orange[600]),
              title: Text(
                'Limpar Dados',
                style: TextStyle(color: Colors.orange[600]),
              ),
              subtitle: const Text('Remover todos os registros de mamadas'),
              onTap: () => _confirmClearData(),
            ),
            
            ListTile(
              leading: Icon(Icons.logout, color: Colors.red[600]),
              title: Text(
                'Sair da Conta',
                style: TextStyle(color: Colors.red[600]),
              ),
              onTap: () => _confirmLogout(authService),
            ),
            
            ListTile(
              leading: Icon(Icons.delete_forever, color: Colors.red[700]),
              title: Text(
                'Excluir Conta',
                style: TextStyle(color: Colors.red[700]),
              ),
              subtitle: const Text('Remover permanentemente sua conta'),
              onTap: () => _confirmDeleteAccount(authService, babyService),
            ),
          ],
        ),
      ),
    );
  }

  String _formatDate(DateTime date) {
    final months = [
      'janeiro', 'fevereiro', 'março', 'abril', 'maio', 'junho',
      'julho', 'agosto', 'setembro', 'outubro', 'novembro', 'dezembro'
    ];
    return '${months[date.month - 1]} de ${date.year}';
  }

  void _showEditProfileDialog(user) {
    final nameController = TextEditingController(text: user?.name ?? '');
    
    showDialog(
      context: context,
      builder: (context) => AlertDialog(
        title: const Text('Editar Perfil'),
        content: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            TextField(
              controller: nameController,
              decoration: const InputDecoration(
                labelText: 'Nome',
                hintText: 'Digite seu nome',
              ),
            ),
          ],
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.of(context).pop(),
            child: const Text('Cancelar'),
          ),
          TextButton(
            onPressed: () async {
              Navigator.of(context).pop();
              final authService = Provider.of<AuthService>(context, listen: false);
              final success = await authService.updateProfile(
                name: nameController.text.trim(),
              );
              
              if (mounted) {
                ScaffoldMessenger.of(context).showSnackBar(
                  SnackBar(
                    content: Text(success 
                        ? 'Perfil atualizado com sucesso'
                        : 'Erro ao atualizar perfil'),
                    backgroundColor: success ? Colors.green : Colors.red,
                  ),
                );
              }
            },
            child: const Text('Salvar'),
          ),
        ],
      ),
    );
  }

  void _showVersionInfo() {
    showDialog(
      context: context,
      builder: (context) => AlertDialog(
        title: const Text('MãeConecta'),
        content: const Column(
          mainAxisSize: MainAxisSize.min,
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text('Versão: 1.0.0'),
            SizedBox(height: 8),
            Text('Desenvolvido para apoiar mães de primeira viagem com dicas personalizadas e acompanhamento da alimentação do bebê.'),
            SizedBox(height: 8),
            Text('Todas as dicas são baseadas em diretrizes pediátricas e validadas por profissionais de saúde.'),
          ],
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.of(context).pop(),
            child: const Text('Fechar'),
          ),
        ],
      ),
    );
  }

  void _showTermsOfService() {
    showDialog(
      context: context,
      builder: (context) => AlertDialog(
        title: const Text('Termos de Uso'),
        content: const SingleChildScrollView(
          child: Text(
            'Ao usar o MãeConecta, você concorda com os seguintes termos:\n\n'
            '1. O aplicativo fornece informações educativas e não substitui consultas médicas.\n\n'
            '2. Sempre consulte um pediatra para questões de saúde do seu bebê.\n\n'
            '3. Seus dados são armazenados localmente e não são compartilhados.\n\n'
            '4. Use as recomendações como guia, observando sempre as necessidades individuais do seu bebê.',
          ),
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.of(context).pop(),
            child: const Text('Fechar'),
          ),
        ],
      ),
    );
  }

  void _showPrivacyPolicy() {
    showDialog(
      context: context,
      builder: (context) => AlertDialog(
        title: const Text('Política de Privacidade'),
        content: const SingleChildScrollView(
          child: Text(
            'Sua privacidade é importante para nós:\n\n'
            '• Todos os dados são armazenados localmente no seu dispositivo\n'
            '• Não coletamos informações pessoais\n'
            '• Não compartilhamos dados com terceiros\n'
            '• Você pode excluir seus dados a qualquer momento\n'
            '• Não utilizamos cookies ou rastreamento\n\n'
            'Para dúvidas sobre privacidade, entre em contato conosco.',
          ),
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.of(context).pop(),
            child: const Text('Fechar'),
          ),
        ],
      ),
    );
  }

  void _showHelpDialog() {
    showDialog(
      context: context,
      builder: (context) => AlertDialog(
        title: const Text('Ajuda e Suporte'),
        content: const Column(
          mainAxisSize: MainAxisSize.min,
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text('Precisa de ajuda? Aqui estão algumas opções:'),
            SizedBox(height: 16),
            Text('📖 Consulte o manual do usuário nas configurações'),
            SizedBox(height: 8),
            Text('💡 Explore as dicas personalizadas'),
            SizedBox(height: 8),
            Text('📊 Use a calculadora de amamentação'),
            SizedBox(height: 8),
            Text('📱 Mantenha o app atualizado'),
            SizedBox(height: 16),
            Text('Para suporte técnico, entre em contato através das configurações do aplicativo.'),
          ],
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.of(context).pop(),
            child: const Text('Fechar'),
          ),
        ],
      ),
    );
  }

  void _rateApp() {
    ScaffoldMessenger.of(context).showSnackBar(
      const SnackBar(
        content: Text('Obrigado! Esta funcionalidade será implementada na próxima versão.'),
        backgroundColor: Colors.blue,
      ),
    );
  }

  void _exportData() {
    ScaffoldMessenger.of(context).showSnackBar(
      const SnackBar(
        content: Text('Funcionalidade de exportação será implementada na próxima versão.'),
        backgroundColor: Colors.blue,
      ),
    );
  }

  void _confirmClearData() {
    showDialog(
      context: context,
      builder: (context) => AlertDialog(
        title: const Text('Limpar Dados'),
        content: const Text(
          'Tem certeza que deseja remover todos os registros de mamadas? '
          'Esta ação não pode ser desfeita.',
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.of(context).pop(),
            child: const Text('Cancelar'),
          ),
          TextButton(
            onPressed: () {
              Navigator.of(context).pop();
              // TODO: Implementar limpeza de dados
              ScaffoldMessenger.of(context).showSnackBar(
                const SnackBar(
                  content: Text('Dados limpos com sucesso'),
                  backgroundColor: Colors.orange,
                ),
              );
            },
            child: Text(
              'Limpar',
              style: TextStyle(color: Colors.orange[600]),
            ),
          ),
        ],
      ),
    );
  }

  void _confirmLogout(AuthService authService) {
    showDialog(
      context: context,
      builder: (context) => AlertDialog(
        title: const Text('Sair da Conta'),
        content: const Text('Tem certeza que deseja sair da sua conta?'),
        actions: [
          TextButton(
            onPressed: () => Navigator.of(context).pop(),
            child: const Text('Cancelar'),
          ),
          TextButton(
            onPressed: () async {
              Navigator.of(context).pop();
              await authService.logout();
              if (mounted) {
                context.go('/login');
              }
            },
            child: Text(
              'Sair',
              style: TextStyle(color: Colors.red[600]),
            ),
          ),
        ],
      ),
    );
  }

  void _confirmDeleteAccount(AuthService authService, BabyService babyService) {
    showDialog(
      context: context,
      builder: (context) => AlertDialog(
        title: const Text('Excluir Conta'),
        content: const Text(
          'ATENÇÃO: Esta ação irá excluir permanentemente sua conta e todos os dados. '
          'Esta ação não pode ser desfeita.',
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.of(context).pop(),
            child: const Text('Cancelar'),
          ),
          TextButton(
            onPressed: () async {
              Navigator.of(context).pop();
              // TODO: Implementar exclusão de conta
              ScaffoldMessenger.of(context).showSnackBar(
                const SnackBar(
                  content: Text('Funcionalidade será implementada na próxima versão'),
                  backgroundColor: Colors.red,
                ),
              );
            },
            child: Text(
              'Excluir Permanentemente',
              style: TextStyle(color: Colors.red[700]),
            ),
          ),
        ],
      ),
    );
  }
}

