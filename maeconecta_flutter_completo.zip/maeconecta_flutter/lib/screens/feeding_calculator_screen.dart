// NOTA PARA LUIS E GRUPO PIME:
// Esta tela implementa a calculadora de amamentação baseada na idade do bebê.
// Segue as diretrizes da Sociedade Brasileira de Pediatria.

import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'package:go_router/go_router.dart';
import '../services/baby_service.dart';
import '../services/notification_service.dart';

class FeedingCalculatorScreen extends StatefulWidget {
  const FeedingCalculatorScreen({super.key});

  @override
  State<FeedingCalculatorScreen> createState() => _FeedingCalculatorScreenState();
}

class _FeedingCalculatorScreenState extends State<FeedingCalculatorScreen> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Calculadora de Amamentação'),
        leading: IconButton(
          icon: const Icon(Icons.arrow_back),
          onPressed: () => context.go('/home'),
        ),
      ),
      body: Consumer<BabyService>(
        builder: (context, babyService, child) {
          if (!babyService.hasBaby) {
            return _buildNoBabyState();
          }

          final baby = babyService.currentBaby!;
          final recommendation = babyService.getFeedingRecommendation();

          if (recommendation == null) {
            return _buildNoRecommendationState();
          }

          return SingleChildScrollView(
            padding: const EdgeInsets.all(16),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                // Informações do bebê
                _buildBabyInfoCard(baby),
                
                const SizedBox(height: 16),
                
                // Recomendações principais
                _buildRecommendationCard(recommendation),
                
                const SizedBox(height: 16),
                
                // Detalhes por tipo de alimentação
                _buildFeedingTypesCard(recommendation),
                
                const SizedBox(height: 16),
                
                // Dicas importantes
                _buildTipsCard(recommendation),
                
                const SizedBox(height: 16),
                
                // Ações
                _buildActionsCard(baby, recommendation),
              ],
            ),
          );
        },
      ),
    );
  }

  Widget _buildNoBabyState() {
    return Center(
      child: Padding(
        padding: const EdgeInsets.all(24),
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Icon(
              Icons.baby_changing_station,
              size: 64,
              color: Colors.grey[400],
            ),
            const SizedBox(height: 16),
            Text(
              'Nenhum bebê cadastrado',
              style: Theme.of(context).textTheme.titleLarge?.copyWith(
                fontWeight: FontWeight.bold,
              ),
            ),
            const SizedBox(height: 8),
            Text(
              'Para usar a calculadora, primeiro cadastre as informações do seu bebê',
              style: Theme.of(context).textTheme.bodyMedium?.copyWith(
                color: Colors.grey[600],
              ),
              textAlign: TextAlign.center,
            ),
            const SizedBox(height: 24),
            ElevatedButton(
              onPressed: () => context.go('/baby-profile'),
              child: const Text('Cadastrar Bebê'),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildNoRecommendationState() {
    return Center(
      child: Padding(
        padding: const EdgeInsets.all(24),
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Icon(
              Icons.error_outline,
              size: 64,
              color: Colors.orange[400],
            ),
            const SizedBox(height: 16),
            Text(
              'Não foi possível calcular',
              style: Theme.of(context).textTheme.titleLarge?.copyWith(
                fontWeight: FontWeight.bold,
              ),
            ),
            const SizedBox(height: 8),
            Text(
              'Verifique se a data de nascimento do bebê está correta',
              style: Theme.of(context).textTheme.bodyMedium?.copyWith(
                color: Colors.grey[600],
              ),
              textAlign: TextAlign.center,
            ),
            const SizedBox(height: 24),
            ElevatedButton(
              onPressed: () => context.go('/baby-profile'),
              child: const Text('Editar Perfil do Bebê'),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildBabyInfoCard(baby) {
    return Card(
      child: Padding(
        padding: const EdgeInsets.all(16),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Row(
              children: [
                CircleAvatar(
                  radius: 24,
                  backgroundColor: Theme.of(context).colorScheme.primary,
                  child: Text(
                    baby.name.substring(0, 1).toUpperCase(),
                    style: const TextStyle(
                      fontSize: 18,
                      fontWeight: FontWeight.bold,
                      color: Colors.white,
                    ),
                  ),
                ),
                const SizedBox(width: 12),
                Expanded(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(
                        baby.name,
                        style: Theme.of(context).textTheme.titleMedium?.copyWith(
                          fontWeight: FontWeight.bold,
                        ),
                      ),
                      Text(
                        baby.ageFriendlyDescription,
                        style: Theme.of(context).textTheme.bodyMedium?.copyWith(
                          color: Colors.grey[600],
                        ),
                      ),
                    ],
                  ),
                ),
                Container(
                  padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 4),
                  decoration: BoxDecoration(
                    color: Theme.of(context).colorScheme.primary.withOpacity(0.1),
                    borderRadius: BorderRadius.circular(12),
                  ),
                  child: Text(
                    baby.ageCategory,
                    style: TextStyle(
                      fontSize: 12,
                      color: Theme.of(context).colorScheme.primary,
                      fontWeight: FontWeight.w500,
                    ),
                  ),
                ),
              ],
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildRecommendationCard(recommendation) {
    return Card(
      child: Padding(
        padding: const EdgeInsets.all(16),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Row(
              children: [
                Icon(
                  Icons.calculate,
                  color: Theme.of(context).colorScheme.primary,
                  size: 24,
                ),
                const SizedBox(width: 8),
                Text(
                  'Recomendações',
                  style: Theme.of(context).textTheme.titleMedium?.copyWith(
                    fontWeight: FontWeight.bold,
                  ),
                ),
              ],
            ),
            
            const SizedBox(height: 16),
            
            // Grid de informações principais
            Row(
              children: [
                Expanded(
                  child: _buildStatCard(
                    icon: Icons.local_drink,
                    title: 'Volume por Mamada',
                    value: '${recommendation.volumeRange.min}-${recommendation.volumeRange.max}ml',
                    subtitle: 'Média: ${recommendation.averageVolume}ml',
                  ),
                ),
                const SizedBox(width: 12),
                Expanded(
                  child: _buildStatCard(
                    icon: Icons.restaurant,
                    title: 'Mamadas por Dia',
                    value: '${recommendation.feedingsPerDay.min}-${recommendation.feedingsPerDay.max}x',
                    subtitle: 'Média: ${recommendation.averageFeedings}x',
                  ),
                ),
              ],
            ),
            
            const SizedBox(height: 12),
            
            Row(
              children: [
                Expanded(
                  child: _buildStatCard(
                    icon: Icons.schedule,
                    title: 'Intervalo',
                    value: '${recommendation.intervalHours}h',
                    subtitle: 'Entre mamadas',
                  ),
                ),
                const SizedBox(width: 12),
                Expanded(
                  child: _buildStatCard(
                    icon: Icons.analytics,
                    title: 'Volume Diário',
                    value: '~${recommendation.dailyVolumeEstimate}ml',
                    subtitle: 'Estimativa total',
                  ),
                ),
              ],
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildStatCard({
    required IconData icon,
    required String title,
    required String value,
    required String subtitle,
  }) {
    return Container(
      padding: const EdgeInsets.all(12),
      decoration: BoxDecoration(
        color: Theme.of(context).colorScheme.primary.withOpacity(0.05),
        borderRadius: BorderRadius.circular(8),
        border: Border.all(
          color: Theme.of(context).colorScheme.primary.withOpacity(0.1),
        ),
      ),
      child: Column(
        children: [
          Icon(
            icon,
            color: Theme.of(context).colorScheme.primary,
            size: 20,
          ),
          const SizedBox(height: 4),
          Text(
            title,
            style: const TextStyle(
              fontSize: 11,
              fontWeight: FontWeight.w500,
            ),
            textAlign: TextAlign.center,
          ),
          const SizedBox(height: 2),
          Text(
            value,
            style: const TextStyle(
              fontSize: 14,
              fontWeight: FontWeight.bold,
            ),
            textAlign: TextAlign.center,
          ),
          Text(
            subtitle,
            style: TextStyle(
              fontSize: 10,
              color: Colors.grey[600],
            ),
            textAlign: TextAlign.center,
          ),
        ],
      ),
    );
  }

  Widget _buildFeedingTypesCard(recommendation) {
    return Card(
      child: Padding(
        padding: const EdgeInsets.all(16),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Row(
              children: [
                Icon(
                  Icons.info_outline,
                  color: Theme.of(context).colorScheme.primary,
                  size: 24,
                ),
                const SizedBox(width: 8),
                Text(
                  'Tipos de Alimentação',
                  style: Theme.of(context).textTheme.titleMedium?.copyWith(
                    fontWeight: FontWeight.bold,
                  ),
                ),
              ],
            ),
            
            const SizedBox(height: 16),
            
            // Amamentação
            _buildFeedingTypeItem(
              icon: Icons.favorite,
              title: 'Amamentação (Peito)',
              description: 'Alimento ideal para o bebê. Oferece anticorpos e nutrientes perfeitos.',
              recommendation: 'Ofereça sob livre demanda, observando sinais de fome.',
              color: Colors.pink,
            ),
            
            const SizedBox(height: 12),
            
            // Mamadeira
            _buildFeedingTypeItem(
              icon: Icons.local_drink,
              title: 'Mamadeira (Fórmula)',
              description: 'Alternativa quando amamentação não é possível.',
              recommendation: 'Use as quantidades recomendadas acima como referência.',
              color: Colors.blue,
            ),
            
            const SizedBox(height: 12),
            
            // Misto
            _buildFeedingTypeItem(
              icon: Icons.blender,
              title: 'Alimentação Mista',
              description: 'Combinação de amamentação e mamadeira.',
              recommendation: 'Priorize o peito e complemente com fórmula se necessário.',
              color: Colors.purple,
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildFeedingTypeItem({
    required IconData icon,
    required String title,
    required String description,
    required String recommendation,
    required Color color,
  }) {
    return Container(
      padding: const EdgeInsets.all(12),
      decoration: BoxDecoration(
        color: color.withOpacity(0.05),
        borderRadius: BorderRadius.circular(8),
        border: Border.all(color: color.withOpacity(0.2)),
      ),
      child: Row(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Container(
            padding: const EdgeInsets.all(8),
            decoration: BoxDecoration(
              color: color.withOpacity(0.1),
              borderRadius: BorderRadius.circular(6),
            ),
            child: Icon(icon, color: color, size: 20),
          ),
          const SizedBox(width: 12),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  title,
                  style: const TextStyle(
                    fontWeight: FontWeight.bold,
                    fontSize: 14,
                  ),
                ),
                const SizedBox(height: 4),
                Text(
                  description,
                  style: TextStyle(
                    fontSize: 12,
                    color: Colors.grey[700],
                  ),
                ),
                const SizedBox(height: 4),
                Text(
                  recommendation,
                  style: TextStyle(
                    fontSize: 12,
                    color: color,
                    fontWeight: FontWeight.w500,
                  ),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildTipsCard(recommendation) {
    return Card(
      child: Padding(
        padding: const EdgeInsets.all(16),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Row(
              children: [
                Icon(
                  Icons.lightbulb_outline,
                  color: Colors.orange[600],
                  size: 24,
                ),
                const SizedBox(width: 8),
                Text(
                  'Dicas Importantes',
                  style: Theme.of(context).textTheme.titleMedium?.copyWith(
                    fontWeight: FontWeight.bold,
                  ),
                ),
              ],
            ),
            
            const SizedBox(height: 12),
            
            Container(
              padding: const EdgeInsets.all(12),
              decoration: BoxDecoration(
                color: Colors.orange[50],
                borderRadius: BorderRadius.circular(8),
                border: Border.all(color: Colors.orange[200]!),
              ),
              child: Text(
                recommendation.notes,
                style: TextStyle(
                  fontSize: 14,
                  color: Colors.orange[800],
                ),
              ),
            ),
            
            const SizedBox(height: 12),
            
            // Dicas gerais
            _buildTipItem(
              icon: Icons.visibility,
              text: 'Observe sempre os sinais de fome e saciedade do bebê',
            ),
            
            _buildTipItem(
              icon: Icons.medical_services,
              text: 'Consulte o pediatra regularmente para acompanhamento',
            ),
            
            _buildTipItem(
              icon: Icons.schedule,
              text: 'Mantenha um registro das mamadas para identificar padrões',
            ),
            
            _buildTipItem(
              icon: Icons.warning,
              text: 'Procure ajuda médica se houver sinais de desidratação ou problemas',
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildTipItem({required IconData icon, required String text}) {
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 4),
      child: Row(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Icon(
            icon,
            size: 16,
            color: Colors.grey[600],
          ),
          const SizedBox(width: 8),
          Expanded(
            child: Text(
              text,
              style: TextStyle(
                fontSize: 13,
                color: Colors.grey[700],
              ),
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildActionsCard(baby, recommendation) {
    return Card(
      child: Padding(
        padding: const EdgeInsets.all(16),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text(
              'Ações Rápidas',
              style: Theme.of(context).textTheme.titleMedium?.copyWith(
                fontWeight: FontWeight.bold,
              ),
            ),
            
            const SizedBox(height: 16),
            
            Row(
              children: [
                Expanded(
                  child: ElevatedButton.icon(
                    onPressed: () => _showAddFeedingDialog(baby),
                    icon: const Icon(Icons.add, size: 18),
                    label: const Text('Registrar Mamada'),
                    style: ElevatedButton.styleFrom(
                      padding: const EdgeInsets.symmetric(vertical: 12),
                    ),
                  ),
                ),
                const SizedBox(width: 12),
                Expanded(
                  child: OutlinedButton.icon(
                    onPressed: () => _scheduleReminder(recommendation),
                    icon: const Icon(Icons.notifications, size: 18),
                    label: const Text('Lembrete'),
                    style: OutlinedButton.styleFrom(
                      padding: const EdgeInsets.symmetric(vertical: 12),
                    ),
                  ),
                ),
              ],
            ),
            
            const SizedBox(height: 12),
            
            SizedBox(
              width: double.infinity,
              child: OutlinedButton.icon(
                onPressed: () => context.go('/feeding-log'),
                icon: const Icon(Icons.history, size: 18),
                label: const Text('Ver Histórico de Mamadas'),
                style: OutlinedButton.styleFrom(
                  padding: const EdgeInsets.symmetric(vertical: 12),
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }

  void _showAddFeedingDialog(baby) {
    // TODO: Implementar dialog para adicionar mamada
    ScaffoldMessenger.of(context).showSnackBar(
      const SnackBar(
        content: Text('Funcionalidade de registro será implementada na próxima versão'),
        backgroundColor: Colors.blue,
      ),
    );
  }

  void _scheduleReminder(recommendation) async {
    try {
      await NotificationService.scheduleNextFeedingReminder(
        interval: Duration(hours: recommendation.intervalHours),
      );
      
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(
            content: Text(
              'Lembrete agendado para ${recommendation.intervalHours}h',
            ),
            backgroundColor: Colors.green,
          ),
        );
      }
    } catch (e) {
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(
            content: Text('Erro ao agendar lembrete'),
            backgroundColor: Colors.red,
          ),
        );
      }
    }
  }
}

