// NOTA PARA LUIS E GRUPO PIME:
// Esta tela exibe o histórico de mamadas e permite adicionar novos registros.
// Inclui estatísticas e visualizações dos dados de alimentação.

import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'package:go_router/go_router.dart';
import 'package:intl/intl.dart';
import '../services/baby_service.dart';
import '../services/feeding_service.dart';
import '../models/feeding_record.dart';

class FeedingLogScreen extends StatefulWidget {
  const FeedingLogScreen({super.key});

  @override
  State<FeedingLogScreen> createState() => _FeedingLogScreenState();
}

class _FeedingLogScreenState extends State<FeedingLogScreen>
    with SingleTickerProviderStateMixin {
  late TabController _tabController;
  int _selectedPeriod = 0; // 0: Hoje, 1: Semana, 2: Mês

  @override
  void initState() {
    super.initState();
    _tabController = TabController(length: 2, vsync: this);
  }

  @override
  void dispose() {
    _tabController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Histórico de Mamadas'),
        leading: IconButton(
          icon: const Icon(Icons.arrow_back),
          onPressed: () => context.go('/home'),
        ),
        bottom: TabBar(
          controller: _tabController,
          tabs: const [
            Tab(text: 'Histórico', icon: Icon(Icons.history)),
            Tab(text: 'Estatísticas', icon: Icon(Icons.analytics)),
          ],
        ),
      ),
      body: Consumer2<BabyService, FeedingService>(
        builder: (context, babyService, feedingService, child) {
          if (!babyService.hasBaby) {
            return _buildNoBabyState();
          }

          return TabBarView(
            controller: _tabController,
            children: [
              _buildHistoryView(babyService, feedingService),
              _buildStatsView(babyService, feedingService),
            ],
          );
        },
      ),
      floatingActionButton: Consumer<BabyService>(
        builder: (context, babyService, child) {
          if (!babyService.hasBaby) return const SizedBox.shrink();
          
          return FloatingActionButton(
            onPressed: () => _showAddFeedingDialog(babyService.currentBaby!),
            child: const Icon(Icons.add),
          );
        },
      ),
    );
  }

  Widget _buildNoBabyState() {
    return Center(
      child: Padding(
        padding: const EdgeInsets.all(24),
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Icon(
              Icons.baby_changing_station,
              size: 64,
              color: Colors.grey[400],
            ),
            const SizedBox(height: 16),
            Text(
              'Nenhum bebê cadastrado',
              style: Theme.of(context).textTheme.titleLarge?.copyWith(
                fontWeight: FontWeight.bold,
              ),
            ),
            const SizedBox(height: 8),
            Text(
              'Para registrar mamadas, primeiro cadastre as informações do seu bebê',
              style: Theme.of(context).textTheme.bodyMedium?.copyWith(
                color: Colors.grey[600],
              ),
              textAlign: TextAlign.center,
            ),
            const SizedBox(height: 24),
            ElevatedButton(
              onPressed: () => context.go('/baby-profile'),
              child: const Text('Cadastrar Bebê'),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildHistoryView(BabyService babyService, FeedingService feedingService) {
    final baby = babyService.currentBaby!;
    final records = feedingService.getFeedingRecordsForBaby(baby.id);

    return Column(
      children: [
        // Resumo rápido
        _buildQuickSummary(baby, feedingService),
        
        // Lista de registros
        Expanded(
          child: records.isEmpty
              ? _buildEmptyHistoryState()
              : ListView.builder(
                  padding: const EdgeInsets.all(16),
                  itemCount: records.length,
                  itemBuilder: (context, index) {
                    final record = records[index];
                    final isToday = _isToday(record.timestamp);
                    final showDateHeader = index == 0 || 
                        !_isSameDay(record.timestamp, records[index - 1].timestamp);
                    
                    return Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        if (showDateHeader) ...[
                          if (index > 0) const SizedBox(height: 16),
                          Padding(
                            padding: const EdgeInsets.symmetric(vertical: 8),
                            child: Text(
                              isToday 
                                  ? 'Hoje'
                                  : DateFormat('EEEE, d MMMM', 'pt_BR').format(record.timestamp),
                              style: Theme.of(context).textTheme.titleSmall?.copyWith(
                                fontWeight: FontWeight.bold,
                                color: Theme.of(context).colorScheme.primary,
                              ),
                            ),
                          ),
                        ],
                        _buildFeedingRecordCard(record, feedingService),
                        const SizedBox(height: 8),
                      ],
                    );
                  },
                ),
        ),
      ],
    );
  }

  Widget _buildStatsView(BabyService babyService, FeedingService feedingService) {
    final baby = babyService.currentBaby!;
    
    return SingleChildScrollView(
      padding: const EdgeInsets.all(16),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          // Seletor de período
          _buildPeriodSelector(),
          
          const SizedBox(height: 16),
          
          // Estatísticas do período
          _buildPeriodStats(baby, feedingService),
          
          const SizedBox(height: 16),
          
          // Gráfico de mamadas por dia (simulado)
          _buildFeedingChart(baby, feedingService),
          
          const SizedBox(height: 16),
          
          // Distribuição por tipo
          _buildTypeDistribution(baby, feedingService),
        ],
      ),
    );
  }

  Widget _buildQuickSummary(baby, FeedingService feedingService) {
    final todayStats = feedingService.getTodayStats(baby.id);
    final lastFeeding = feedingService.getLastFeedingRecord(baby.id);
    final timeSinceLastFeeding = feedingService.getTimeSinceLastFeeding(baby.id);

    return Container(
      padding: const EdgeInsets.all(16),
      color: Theme.of(context).colorScheme.primary.withOpacity(0.05),
      child: Column(
        children: [
          Row(
            children: [
              Expanded(
                child: _buildSummaryItem(
                  icon: Icons.restaurant,
                  label: 'Hoje',
                  value: '${todayStats.totalFeedings}',
                  subtitle: 'mamadas',
                ),
              ),
              Container(width: 1, height: 40, color: Colors.grey[300]),
              Expanded(
                child: _buildSummaryItem(
                  icon: Icons.local_drink,
                  label: 'Volume',
                  value: '${todayStats.totalVolumeMl}ml',
                  subtitle: 'total',
                ),
              ),
              Container(width: 1, height: 40, color: Colors.grey[300]),
              Expanded(
                child: _buildSummaryItem(
                  icon: Icons.schedule,
                  label: 'Última',
                  value: timeSinceLastFeeding != null 
                      ? _formatDuration(timeSinceLastFeeding)
                      : '--',
                  subtitle: 'há',
                ),
              ),
            ],
          ),
          
          if (lastFeeding != null) ...[
            const SizedBox(height: 12),
            Container(
              padding: const EdgeInsets.all(8),
              decoration: BoxDecoration(
                color: Colors.white,
                borderRadius: BorderRadius.circular(8),
                border: Border.all(color: Colors.grey[300]!),
              ),
              child: Row(
                children: [
                  Icon(
                    _getFeedingTypeIcon(lastFeeding.type),
                    size: 16,
                    color: Theme.of(context).colorScheme.primary,
                  ),
                  const SizedBox(width: 8),
                  Text(
                    'Última mamada: ${lastFeeding.description} às ${DateFormat('HH:mm').format(lastFeeding.timestamp)}',
                    style: const TextStyle(fontSize: 12),
                  ),
                ],
              ),
            ),
          ],
        ],
      ),
    );
  }

  Widget _buildSummaryItem({
    required IconData icon,
    required String label,
    required String value,
    required String subtitle,
  }) {
    return Column(
      children: [
        Icon(
          icon,
          color: Theme.of(context).colorScheme.primary,
          size: 20,
        ),
        const SizedBox(height: 4),
        Text(
          value,
          style: const TextStyle(
            fontSize: 16,
            fontWeight: FontWeight.bold,
          ),
        ),
        Text(
          '$label $subtitle',
          style: TextStyle(
            fontSize: 11,
            color: Colors.grey[600],
          ),
          textAlign: TextAlign.center,
        ),
      ],
    );
  }

  Widget _buildFeedingRecordCard(FeedingRecord record, FeedingService feedingService) {
    return Card(
      child: ListTile(
        leading: CircleAvatar(
          backgroundColor: _getFeedingTypeColor(record.type).withOpacity(0.1),
          child: Icon(
            _getFeedingTypeIcon(record.type),
            color: _getFeedingTypeColor(record.type),
            size: 20,
          ),
        ),
        title: Text(
          record.description,
          style: const TextStyle(fontWeight: FontWeight.w500),
        ),
        subtitle: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text(DateFormat('HH:mm').format(record.timestamp)),
            if (record.notes != null && record.notes!.isNotEmpty) ...[
              const SizedBox(height: 4),
              Text(
                record.notes!,
                style: TextStyle(
                  fontSize: 12,
                  color: Colors.grey[600],
                  fontStyle: FontStyle.italic,
                ),
              ),
            ],
          ],
        ),
        trailing: PopupMenuButton(
          itemBuilder: (context) => [
            const PopupMenuItem(
              value: 'edit',
              child: Row(
                children: [
                  Icon(Icons.edit, size: 18),
                  SizedBox(width: 8),
                  Text('Editar'),
                ],
              ),
            ),
            const PopupMenuItem(
              value: 'delete',
              child: Row(
                children: [
                  Icon(Icons.delete, size: 18, color: Colors.red),
                  SizedBox(width: 8),
                  Text('Excluir', style: TextStyle(color: Colors.red)),
                ],
              ),
            ),
          ],
          onSelected: (value) {
            if (value == 'delete') {
              _confirmDeleteRecord(record, feedingService);
            } else if (value == 'edit') {
              _showEditFeedingDialog(record);
            }
          },
        ),
      ),
    );
  }

  Widget _buildEmptyHistoryState() {
    return Center(
      child: Padding(
        padding: const EdgeInsets.all(24),
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Icon(
              Icons.history,
              size: 64,
              color: Colors.grey[400],
            ),
            const SizedBox(height: 16),
            Text(
              'Nenhuma mamada registrada',
              style: Theme.of(context).textTheme.titleMedium?.copyWith(
                fontWeight: FontWeight.bold,
              ),
            ),
            const SizedBox(height: 8),
            Text(
              'Comece registrando a primeira mamada do seu bebê',
              style: Theme.of(context).textTheme.bodyMedium?.copyWith(
                color: Colors.grey[600],
              ),
              textAlign: TextAlign.center,
            ),
            const SizedBox(height: 24),
            ElevatedButton.icon(
              onPressed: () => _showAddFeedingDialog(
                Provider.of<BabyService>(context, listen: false).currentBaby!,
              ),
              icon: const Icon(Icons.add),
              label: const Text('Registrar Mamada'),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildPeriodSelector() {
    return Row(
      children: [
        Text(
          'Período:',
          style: Theme.of(context).textTheme.titleSmall?.copyWith(
            fontWeight: FontWeight.bold,
          ),
        ),
        const SizedBox(width: 12),
        Expanded(
          child: SingleChildScrollView(
            scrollDirection: Axis.horizontal,
            child: Row(
              children: [
                _buildPeriodChip('Hoje', 0),
                const SizedBox(width: 8),
                _buildPeriodChip('Semana', 1),
                const SizedBox(width: 8),
                _buildPeriodChip('Mês', 2),
              ],
            ),
          ),
        ),
      ],
    );
  }

  Widget _buildPeriodChip(String label, int index) {
    return FilterChip(
      label: Text(label),
      selected: _selectedPeriod == index,
      onSelected: (selected) {
        setState(() {
          _selectedPeriod = index;
        });
      },
    );
  }

  Widget _buildPeriodStats(baby, FeedingService feedingService) {
    FeedingStats stats;
    String periodLabel;
    
    switch (_selectedPeriod) {
      case 0:
        stats = feedingService.getTodayStats(baby.id);
        periodLabel = 'Hoje';
        break;
      case 1:
        stats = feedingService.getWeekStats(baby.id);
        periodLabel = 'Esta Semana';
        break;
      case 2:
        final now = DateTime.now();
        final startOfMonth = DateTime(now.year, now.month, 1);
        stats = feedingService.getFeedingStats(baby.id, startOfMonth, now);
        periodLabel = 'Este Mês';
        break;
      default:
        stats = feedingService.getTodayStats(baby.id);
        periodLabel = 'Hoje';
    }

    return Card(
      child: Padding(
        padding: const EdgeInsets.all(16),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text(
              'Estatísticas - $periodLabel',
              style: Theme.of(context).textTheme.titleMedium?.copyWith(
                fontWeight: FontWeight.bold,
              ),
            ),
            
            const SizedBox(height: 16),
            
            Row(
              children: [
                Expanded(
                  child: _buildStatCard(
                    'Total de Mamadas',
                    '${stats.totalFeedings}',
                    Icons.restaurant,
                    Colors.blue,
                  ),
                ),
                const SizedBox(width: 12),
                Expanded(
                  child: _buildStatCard(
                    'Volume Total',
                    '${stats.totalVolumeMl}ml',
                    Icons.local_drink,
                    Colors.green,
                  ),
                ),
              ],
            ),
            
            const SizedBox(height: 12),
            
            Row(
              children: [
                Expanded(
                  child: _buildStatCard(
                    'Média por Mamada',
                    '${stats.averageVolumeMl}ml',
                    Icons.analytics,
                    Colors.orange,
                  ),
                ),
                const SizedBox(width: 12),
                Expanded(
                  child: _buildStatCard(
                    'Duração Média',
                    '${stats.averageDurationMinutes}min',
                    Icons.timer,
                    Colors.purple,
                  ),
                ),
              ],
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildStatCard(String title, String value, IconData icon, Color color) {
    return Container(
      padding: const EdgeInsets.all(12),
      decoration: BoxDecoration(
        color: color.withOpacity(0.1),
        borderRadius: BorderRadius.circular(8),
        border: Border.all(color: color.withOpacity(0.3)),
      ),
      child: Column(
        children: [
          Icon(icon, color: color, size: 24),
          const SizedBox(height: 8),
          Text(
            value,
            style: TextStyle(
              fontSize: 18,
              fontWeight: FontWeight.bold,
              color: color,
            ),
          ),
          Text(
            title,
            style: const TextStyle(fontSize: 12),
            textAlign: TextAlign.center,
          ),
        ],
      ),
    );
  }

  Widget _buildFeedingChart(baby, FeedingService feedingService) {
    return Card(
      child: Padding(
        padding: const EdgeInsets.all(16),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text(
              'Mamadas por Dia (Últimos 7 dias)',
              style: Theme.of(context).textTheme.titleMedium?.copyWith(
                fontWeight: FontWeight.bold,
              ),
            ),
            
            const SizedBox(height: 16),
            
            // Gráfico simplificado (barras horizontais)
            ...List.generate(7, (index) {
              final date = DateTime.now().subtract(Duration(days: 6 - index));
              final dayRecords = feedingService.getFeedingRecordsForBaby(baby.id)
                  .where((record) => _isSameDay(record.timestamp, date))
                  .length;
              
              return Padding(
                padding: const EdgeInsets.symmetric(vertical: 4),
                child: Row(
                  children: [
                    SizedBox(
                      width: 40,
                      child: Text(
                        DateFormat('dd/MM').format(date),
                        style: const TextStyle(fontSize: 12),
                      ),
                    ),
                    const SizedBox(width: 8),
                    Expanded(
                      child: Stack(
                        children: [
                          Container(
                            height: 20,
                            decoration: BoxDecoration(
                              color: Colors.grey[200],
                              borderRadius: BorderRadius.circular(10),
                            ),
                          ),
                          Container(
                            height: 20,
                            width: (dayRecords / 10) * MediaQuery.of(context).size.width * 0.6,
                            decoration: BoxDecoration(
                              color: Theme.of(context).colorScheme.primary,
                              borderRadius: BorderRadius.circular(10),
                            ),
                          ),
                        ],
                      ),
                    ),
                    const SizedBox(width: 8),
                    SizedBox(
                      width: 20,
                      child: Text(
                        '$dayRecords',
                        style: const TextStyle(
                          fontSize: 12,
                          fontWeight: FontWeight.bold,
                        ),
                      ),
                    ),
                  ],
                ),
              );
            }),
          ],
        ),
      ),
    );
  }

  Widget _buildTypeDistribution(baby, FeedingService feedingService) {
    final records = feedingService.getFeedingRecordsForBaby(baby.id);
    final breastfeeding = records.where((r) => r.type == FeedingType.breastfeeding).length;
    final bottle = records.where((r) => r.type == FeedingType.bottle).length;
    final mixed = records.where((r) => r.type == FeedingType.mixed).length;
    final total = records.length;

    if (total == 0) return const SizedBox.shrink();

    return Card(
      child: Padding(
        padding: const EdgeInsets.all(16),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text(
              'Distribuição por Tipo',
              style: Theme.of(context).textTheme.titleMedium?.copyWith(
                fontWeight: FontWeight.bold,
              ),
            ),
            
            const SizedBox(height: 16),
            
            _buildTypeDistributionItem(
              'Amamentação',
              breastfeeding,
              total,
              Colors.pink,
              Icons.favorite,
            ),
            
            _buildTypeDistributionItem(
              'Mamadeira',
              bottle,
              total,
              Colors.blue,
              Icons.local_drink,
            ),
            
            _buildTypeDistributionItem(
              'Misto',
              mixed,
              total,
              Colors.purple,
              Icons.blender,
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildTypeDistributionItem(
    String label,
    int count,
    int total,
    Color color,
    IconData icon,
  ) {
    final percentage = total > 0 ? (count / total * 100).round() : 0;
    
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 4),
      child: Row(
        children: [
          Icon(icon, color: color, size: 20),
          const SizedBox(width: 8),
          SizedBox(
            width: 80,
            child: Text(
              label,
              style: const TextStyle(fontSize: 12),
            ),
          ),
          Expanded(
            child: Stack(
              children: [
                Container(
                  height: 16,
                  decoration: BoxDecoration(
                    color: Colors.grey[200],
                    borderRadius: BorderRadius.circular(8),
                  ),
                ),
                Container(
                  height: 16,
                  width: (percentage / 100) * MediaQuery.of(context).size.width * 0.4,
                  decoration: BoxDecoration(
                    color: color,
                    borderRadius: BorderRadius.circular(8),
                  ),
                ),
              ],
            ),
          ),
          const SizedBox(width: 8),
          SizedBox(
            width: 50,
            child: Text(
              '$count ($percentage%)',
              style: const TextStyle(
                fontSize: 12,
                fontWeight: FontWeight.bold,
              ),
            ),
          ),
        ],
      ),
    );
  }

  // Métodos auxiliares
  bool _isToday(DateTime date) {
    final now = DateTime.now();
    return date.year == now.year && date.month == now.month && date.day == now.day;
  }

  bool _isSameDay(DateTime date1, DateTime date2) {
    return date1.year == date2.year && 
           date1.month == date2.month && 
           date1.day == date2.day;
  }

  String _formatDuration(Duration duration) {
    if (duration.inHours > 0) {
      return '${duration.inHours}h ${duration.inMinutes % 60}min';
    } else {
      return '${duration.inMinutes}min';
    }
  }

  IconData _getFeedingTypeIcon(FeedingType type) {
    switch (type) {
      case FeedingType.breastfeeding:
        return Icons.favorite;
      case FeedingType.bottle:
        return Icons.local_drink;
      case FeedingType.mixed:
        return Icons.blender;
    }
  }

  Color _getFeedingTypeColor(FeedingType type) {
    switch (type) {
      case FeedingType.breastfeeding:
        return Colors.pink;
      case FeedingType.bottle:
        return Colors.blue;
      case FeedingType.mixed:
        return Colors.purple;
    }
  }

  void _showAddFeedingDialog(baby) {
    // TODO: Implementar dialog completo para adicionar mamada
    ScaffoldMessenger.of(context).showSnackBar(
      const SnackBar(
        content: Text('Funcionalidade de registro será implementada na próxima versão'),
        backgroundColor: Colors.blue,
      ),
    );
  }

  void _showEditFeedingDialog(FeedingRecord record) {
    // TODO: Implementar dialog para editar mamada
    ScaffoldMessenger.of(context).showSnackBar(
      const SnackBar(
        content: Text('Funcionalidade de edição será implementada na próxima versão'),
        backgroundColor: Colors.blue,
      ),
    );
  }

  void _confirmDeleteRecord(FeedingRecord record, FeedingService feedingService) {
    showDialog(
      context: context,
      builder: (context) => AlertDialog(
        title: const Text('Excluir Registro'),
        content: Text(
          'Tem certeza que deseja excluir este registro de ${record.description}?',
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.of(context).pop(),
            child: const Text('Cancelar'),
          ),
          TextButton(
            onPressed: () async {
              Navigator.of(context).pop();
              final success = await feedingService.removeFeedingRecord(record.id);
              if (mounted) {
                ScaffoldMessenger.of(context).showSnackBar(
                  SnackBar(
                    content: Text(success 
                        ? 'Registro excluído com sucesso'
                        : 'Erro ao excluir registro'),
                    backgroundColor: success ? Colors.green : Colors.red,
                  ),
                );
              }
            },
            child: Text(
              'Excluir',
              style: TextStyle(color: Colors.red[600]),
            ),
          ),
        ],
      ),
    );
  }
}

