// NOTA PARA LUIS E GRUPO PIME:
// Esta tela permite cadastrar e editar as informações do bebê.
// É fundamental para personalizar as recomendações do aplicativo.

import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'package:go_router/go_router.dart';
import 'package:intl/intl.dart';
import '../services/auth_service.dart';
import '../services/baby_service.dart';

class BabyProfileScreen extends StatefulWidget {
  const BabyProfileScreen({super.key});

  @override
  State<BabyProfileScreen> createState() => _BabyProfileScreenState();
}

class _BabyProfileScreenState extends State<BabyProfileScreen> {
  final _formKey = GlobalKey<FormState>();
  final _nameController = TextEditingController();
  final _birthDateController = TextEditingController();
  final _birthWeightController = TextEditingController();
  final _specialNeedsController = TextEditingController();
  
  DateTime? _selectedBirthDate;
  bool _isEditing = false;

  @override
  void initState() {
    super.initState();
    _loadBabyData();
  }

  void _loadBabyData() {
    final babyService = Provider.of<BabyService>(context, listen: false);
    final baby = babyService.currentBaby;
    
    if (baby != null) {
      _isEditing = true;
      _nameController.text = baby.name;
      _selectedBirthDate = baby.birthDate;
      _birthDateController.text = DateFormat('dd/MM/yyyy').format(baby.birthDate);
      _birthWeightController.text = baby.birthWeight?.toString() ?? '';
      _specialNeedsController.text = baby.specialNeeds ?? '';
    }
  }

  @override
  void dispose() {
    _nameController.dispose();
    _birthDateController.dispose();
    _birthWeightController.dispose();
    _specialNeedsController.dispose();
    super.dispose();
  }

  Future<void> _selectBirthDate() async {
    final now = DateTime.now();
    final firstDate = DateTime(now.year - 2, now.month, now.day);
    
    final pickedDate = await showDatePicker(
      context: context,
      initialDate: _selectedBirthDate ?? now,
      firstDate: firstDate,
      lastDate: now,
      locale: const Locale('pt', 'BR'),
      helpText: 'Selecione a data de nascimento',
      cancelText: 'Cancelar',
      confirmText: 'Confirmar',
    );

    if (pickedDate != null) {
      setState(() {
        _selectedBirthDate = pickedDate;
        _birthDateController.text = DateFormat('dd/MM/yyyy').format(pickedDate);
      });
    }
  }

  Future<void> _saveBaby() async {
    if (!_formKey.currentState!.validate()) return;
    
    if (_selectedBirthDate == null) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(
          content: Text('Por favor, selecione a data de nascimento'),
          backgroundColor: Colors.red,
        ),
      );
      return;
    }

    final authService = Provider.of<AuthService>(context, listen: false);
    final babyService = Provider.of<BabyService>(context, listen: false);
    
    final userId = authService.currentUser?.id;
    if (userId == null) return;

    double? birthWeight;
    if (_birthWeightController.text.isNotEmpty) {
      birthWeight = double.tryParse(_birthWeightController.text.replaceAll(',', '.'));
    }

    final success = await babyService.saveBaby(
      name: _nameController.text.trim(),
      birthDate: _selectedBirthDate!,
      specialNeeds: _specialNeedsController.text.trim().isEmpty 
          ? null 
          : _specialNeedsController.text.trim(),
      birthWeight: birthWeight,
      userId: userId,
    );

    if (success && mounted) {
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(
          content: Text(_isEditing 
              ? 'Perfil do bebê atualizado com sucesso!' 
              : 'Perfil do bebê criado com sucesso!'),
          backgroundColor: Colors.green,
        ),
      );
      context.go('/home');
    } else if (mounted) {
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(
          content: Text(babyService.errorMessage ?? 'Erro ao salvar perfil'),
          backgroundColor: Colors.red,
        ),
      );
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text(_isEditing ? 'Editar Perfil do Bebê' : 'Perfil do Bebê'),
        leading: IconButton(
          icon: const Icon(Icons.arrow_back),
          onPressed: () => context.go('/home'),
        ),
      ),
      body: SingleChildScrollView(
        padding: const EdgeInsets.all(24.0),
        child: Form(
          key: _formKey,
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.stretch,
            children: [
              // Ícone e título
              Column(
                children: [
                  Container(
                    width: 80,
                    height: 80,
                    decoration: BoxDecoration(
                      color: Theme.of(context).colorScheme.primary.withOpacity(0.1),
                      borderRadius: BorderRadius.circular(40),
                    ),
                    child: Icon(
                      Icons.baby_changing_station,
                      size: 40,
                      color: Theme.of(context).colorScheme.primary,
                    ),
                  ),
                  
                  const SizedBox(height: 16),
                  
                  Text(
                    _isEditing ? 'Atualize as informações do seu bebê' : 'Conte-nos sobre seu bebê',
                    style: Theme.of(context).textTheme.titleLarge?.copyWith(
                      fontWeight: FontWeight.bold,
                    ),
                    textAlign: TextAlign.center,
                  ),
                  
                  const SizedBox(height: 8),
                  
                  Text(
                    'Essas informações nos ajudam a personalizar as dicas e recomendações',
                    style: Theme.of(context).textTheme.bodyMedium?.copyWith(
                      color: Colors.grey[600],
                    ),
                    textAlign: TextAlign.center,
                  ),
                ],
              ),
              
              const SizedBox(height: 32),
              
              // Formulário
              Column(
                children: [
                  // Nome do bebê
                  TextFormField(
                    controller: _nameController,
                    textCapitalization: TextCapitalization.words,
                    decoration: const InputDecoration(
                      labelText: 'Nome do bebê *',
                      hintText: 'Digite o nome do seu bebê',
                      prefixIcon: Icon(Icons.child_care),
                    ),
                    validator: (value) {
                      if (value == null || value.trim().isEmpty) {
                        return 'Por favor, digite o nome do bebê';
                      }
                      if (value.trim().length < 2) {
                        return 'Nome deve ter pelo menos 2 caracteres';
                      }
                      return null;
                    },
                  ),
                  
                  const SizedBox(height: 16),
                  
                  // Data de nascimento
                  TextFormField(
                    controller: _birthDateController,
                    readOnly: true,
                    decoration: const InputDecoration(
                      labelText: 'Data de nascimento *',
                      hintText: 'Selecione a data de nascimento',
                      prefixIcon: Icon(Icons.calendar_today),
                      suffixIcon: Icon(Icons.arrow_drop_down),
                    ),
                    onTap: _selectBirthDate,
                    validator: (value) {
                      if (_selectedBirthDate == null) {
                        return 'Por favor, selecione a data de nascimento';
                      }
                      return null;
                    },
                  ),
                  
                  const SizedBox(height: 16),
                  
                  // Peso ao nascer
                  TextFormField(
                    controller: _birthWeightController,
                    keyboardType: const TextInputType.numberWithOptions(decimal: true),
                    decoration: const InputDecoration(
                      labelText: 'Peso ao nascer (kg)',
                      hintText: 'Ex: 3.2',
                      prefixIcon: Icon(Icons.monitor_weight),
                      suffixText: 'kg',
                    ),
                    validator: (value) {
                      if (value != null && value.isNotEmpty) {
                        final weight = double.tryParse(value.replaceAll(',', '.'));
                        if (weight == null) {
                          return 'Digite um peso válido';
                        }
                        if (weight < 0.5 || weight > 6.0) {
                          return 'Peso deve estar entre 0.5kg e 6.0kg';
                        }
                      }
                      return null;
                    },
                  ),
                  
                  const SizedBox(height: 16),
                  
                  // Necessidades especiais
                  TextFormField(
                    controller: _specialNeedsController,
                    maxLines: 3,
                    textCapitalization: TextCapitalization.sentences,
                    decoration: const InputDecoration(
                      labelText: 'Necessidades especiais',
                      hintText: 'Descreva qualquer condição especial ou observação importante',
                      prefixIcon: Icon(Icons.medical_services),
                      alignLabelWithHint: true,
                    ),
                  ),
                  
                  const SizedBox(height: 32),
                  
                  // Informações sobre idade
                  if (_selectedBirthDate != null) ...[
                    Container(
                      padding: const EdgeInsets.all(16),
                      decoration: BoxDecoration(
                        color: Theme.of(context).colorScheme.primary.withOpacity(0.1),
                        borderRadius: BorderRadius.circular(12),
                        border: Border.all(
                          color: Theme.of(context).colorScheme.primary.withOpacity(0.3),
                        ),
                      ),
                      child: Column(
                        children: [
                          Icon(
                            Icons.info_outline,
                            color: Theme.of(context).colorScheme.primary,
                            size: 24,
                          ),
                          const SizedBox(height: 8),
                          Text(
                            'Informações Calculadas',
                            style: TextStyle(
                              fontWeight: FontWeight.bold,
                              color: Theme.of(context).colorScheme.primary,
                            ),
                          ),
                          const SizedBox(height: 8),
                          _buildAgeInfo(),
                        ],
                      ),
                    ),
                    
                    const SizedBox(height: 24),
                  ],
                  
                  // Botão salvar
                  Consumer<BabyService>(
                    builder: (context, babyService, child) {
                      return SizedBox(
                        width: double.infinity,
                        height: 48,
                        child: ElevatedButton(
                          onPressed: babyService.isLoading ? null : _saveBaby,
                          child: babyService.isLoading
                              ? const SizedBox(
                                  width: 20,
                                  height: 20,
                                  child: CircularProgressIndicator(
                                    strokeWidth: 2,
                                    valueColor: AlwaysStoppedAnimation<Color>(
                                      Colors.white,
                                    ),
                                  ),
                                )
                              : Text(
                                  _isEditing ? 'Atualizar Perfil' : 'Salvar Perfil',
                                  style: const TextStyle(
                                    fontSize: 16,
                                    fontWeight: FontWeight.w600,
                                  ),
                                ),
                        ),
                      );
                    },
                  ),
                  
                  if (_isEditing) ...[
                    const SizedBox(height: 16),
                    
                    // Botão excluir (apenas para edição)
                    TextButton(
                      onPressed: _showDeleteConfirmation,
                      child: Text(
                        'Excluir Perfil do Bebê',
                        style: TextStyle(
                          color: Colors.red[600],
                          fontWeight: FontWeight.w600,
                        ),
                      ),
                    ),
                  ],
                ],
              ),
            ],
          ),
        ),
      ),
    );
  }

  Widget _buildAgeInfo() {
    if (_selectedBirthDate == null) return const SizedBox.shrink();
    
    final now = DateTime.now();
    final ageInDays = now.difference(_selectedBirthDate!).inDays;
    final ageInMonths = ageInDays / 30.4375;
    
    String ageCategory;
    if (ageInMonths <= 1) {
      ageCategory = "0 a 30 dias";
    } else if (ageInMonths <= 2) {
      ageCategory = "30 a 60 dias";
    } else if (ageInMonths <= 3) {
      ageCategory = "2 a 3 meses";
    } else if (ageInMonths <= 6) {
      ageCategory = "3 a 6 meses";
    } else {
      ageCategory = "Acima de 6 meses";
    }
    
    String ageFriendly;
    if (ageInDays < 30) {
      ageFriendly = "$ageInDays dias";
    } else if (ageInMonths < 12) {
      final monthsInt = ageInMonths.floor();
      final remainingDays = (ageInDays - (monthsInt * 30.4375)).round();
      if (remainingDays > 0) {
        ageFriendly = "$monthsInt meses e $remainingDays dias";
      } else {
        ageFriendly = "$monthsInt meses";
      }
    } else {
      final years = (ageInMonths / 12).floor();
      final remainingMonths = (ageInMonths % 12).floor();
      if (remainingMonths > 0) {
        ageFriendly = "$years ano${years > 1 ? 's' : ''} e $remainingMonths meses";
      } else {
        ageFriendly = "$years ano${years > 1 ? 's' : ''}";
      }
    }
    
    return Column(
      children: [
        Row(
          mainAxisAlignment: MainAxisAlignment.spaceBetween,
          children: [
            const Text('Idade atual:'),
            Text(
              ageFriendly,
              style: const TextStyle(fontWeight: FontWeight.bold),
            ),
          ],
        ),
        const SizedBox(height: 4),
        Row(
          mainAxisAlignment: MainAxisAlignment.spaceBetween,
          children: [
            const Text('Categoria:'),
            Text(
              ageCategory,
              style: const TextStyle(fontWeight: FontWeight.bold),
            ),
          ],
        ),
        if (ageInMonths >= 6) ...[
          const SizedBox(height: 4),
          Row(
            children: [
              Icon(
                Icons.restaurant,
                size: 16,
                color: Colors.green[600],
              ),
              const SizedBox(width: 4),
              Expanded(
                child: Text(
                  'Pode iniciar introdução alimentar',
                  style: TextStyle(
                    color: Colors.green[600],
                    fontWeight: FontWeight.w500,
                    fontSize: 12,
                  ),
                ),
              ),
            ],
          ),
        ],
      ],
    );
  }

  void _showDeleteConfirmation() {
    showDialog(
      context: context,
      builder: (context) => AlertDialog(
        title: const Text('Excluir Perfil'),
        content: const Text(
          'Tem certeza que deseja excluir o perfil do bebê? '
          'Esta ação não pode ser desfeita e todos os dados serão perdidos.',
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.of(context).pop(),
            child: const Text('Cancelar'),
          ),
          TextButton(
            onPressed: () async {
              Navigator.of(context).pop();
              final babyService = Provider.of<BabyService>(context, listen: false);
              await babyService.removeBaby();
              if (mounted) {
                ScaffoldMessenger.of(context).showSnackBar(
                  const SnackBar(
                    content: Text('Perfil do bebê excluído'),
                    backgroundColor: Colors.orange,
                  ),
                );
                context.go('/home');
              }
            },
            child: Text(
              'Excluir',
              style: TextStyle(color: Colors.red[600]),
            ),
          ),
        ],
      ),
    );
  }
}

