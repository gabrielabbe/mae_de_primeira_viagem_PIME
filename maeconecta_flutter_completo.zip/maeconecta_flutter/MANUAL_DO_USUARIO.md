# Manual do Usuário - MãeConecta

## Bem-vinda ao MãeConecta! 💕

O MãeConecta é seu companheiro digital para os primeiros cuidados com o bebê. Este aplicativo foi desenvolvido especialmente para mães de primeira viagem, oferecendo orientações confiáveis e personalizadas baseadas na idade do seu bebê.

## Primeiros Passos

### 1. Criando sua Conta

Ao abrir o aplicativo pela primeira vez, você verá a tela de login. Para criar uma nova conta:

1. Toque em "Criar conta"
2. Preencha seus dados:
   - Nome completo
   - Email válido
   - Senha (mínimo 6 caracteres)
   - Confirme sua senha
3. Aceite os termos de uso
4. Toque em "Criar Conta"

**Dica**: Use um email que você acessa frequentemente, pois ele será usado para recuperar sua conta se necessário.

### 2. Fazendo Login

Se você já tem uma conta:

1. Digite seu email e senha
2. Toque em "Entrar"

**Para testes**: Use o email `teste@maeconecta.com` e senha `123456`

### 3. Configurando o Perfil do Bebê

Após fazer login, você precisará adicionar as informações do seu bebê:

1. Na tela inicial, toque em "Adicionar Bebê"
2. Preencha as informações:
   - Nome do bebê
   - Data de nascimento
   - Peso ao nascer (opcional)
   - Necessidades especiais (opcional)
3. Toque em "Salvar"

**Importante**: A data de nascimento é fundamental para que o aplicativo forneça dicas personalizadas para a idade correta do seu bebê.

## Funcionalidades Principais

### Tela Inicial (Dashboard)

A tela inicial é seu centro de controle, onde você encontra:

#### Informações do Bebê
- Nome e idade atual
- Categoria de idade para recomendações
- Botão para editar informações

#### Ações Rápidas
- **Calculadora**: Acesso rápido à calculadora de amamentação
- **Dicas**: Visualizar dicas personalizadas
- **Histórico**: Ver registros de mamadas anteriores
- **Registrar**: Adicionar nova mamada

#### Dica do Dia
Uma dica personalizada baseada na idade do seu bebê, validada por pediatras.

#### Resumo de Hoje
Estatísticas do dia atual:
- Número de mamadas realizadas
- Volume total consumido

#### Próxima Mamada
Informações sobre quando deve ser a próxima alimentação baseada no padrão do seu bebê.

### Calculadora de Amamentação

Esta ferramenta fornece recomendações personalizadas baseadas na idade do seu bebê:

1. Acesse através da tela inicial ou menu
2. As recomendações são calculadas automaticamente
3. Você verá:
   - Volume recomendado por mamada
   - Número de mamadas por dia
   - Intervalo entre mamadas
   - Volume total diário estimado

#### Faixas Etárias e Recomendações

**0 a 30 dias (Recém-nascido)**
- Volume: 60-120ml por mamada
- Frequência: 6-8 mamadas por dia
- Intervalo: A cada 3 horas
- Observação: Período de adaptação, amamente sob demanda

**30 a 60 dias**
- Volume: 120-150ml por mamada
- Frequência: 6-8 mamadas por dia
- Intervalo: A cada 3 horas
- Observação: Padrão mais regular começa a se estabelecer

**2 a 3 meses**
- Volume: 150-180ml por mamada
- Frequência: 5-6 mamadas por dia
- Intervalo: A cada 4 horas
- Observação: Bebê pode ficar mais tempo entre mamadas

**3 a 6 meses**
- Volume: 180-200ml por mamada
- Frequência: 4-5 mamadas por dia
- Intervalo: A cada 4 horas
- Observação: Preparação para introdução alimentar

**Acima de 6 meses**
- Volume: 180-200ml por mamada
- Frequência: 2-3 mamadas por dia
- Intervalo: A cada 6 horas
- Observação: Introdução alimentar iniciada

**Importante**: Estas são orientações gerais. Sempre observe os sinais do seu bebê e consulte seu pediatra.

### Sistema de Dicas Personalizadas

O aplicativo oferece dicas organizadas por categorias:

#### Alimentação 🍼
- Técnicas de amamentação
- Introdução alimentar
- Sinais de fome e saciedade
- Problemas comuns na amamentação

#### Sono 😴
- Posições seguras para dormir
- Rotinas de sono
- Ambiente adequado
- Padrões de sono por idade

#### Higiene 🛁
- Cuidados com o coto umbilical
- Banho do recém-nascido
- Troca de fraldas
- Cuidados com a pele

#### Desenvolvimento 👶
- Marcos do desenvolvimento
- Estímulos adequados para cada idade
- Brincadeiras e atividades
- Sinais de desenvolvimento normal

#### Saúde 🏥
- Sinais de alerta
- Quando procurar o pediatra
- Prevenção de doenças
- Cuidados básicos de saúde

#### Segurança 🛡️
- Segurança em casa
- Transporte seguro
- Prevenção de acidentes
- Produtos seguros para bebês

### Registro de Mamadas

Para acompanhar a alimentação do seu bebê:

1. Toque em "Registrar Mamada" na tela inicial
2. Selecione o tipo de alimentação:
   - **Amamentação**: Registre a duração
   - **Mamadeira**: Registre o volume
   - **Misto**: Registre ambos
3. Adicione observações se necessário
4. Confirme o horário (ou ajuste se necessário)
5. Toque em "Salvar"

#### Visualizando o Histórico

No histórico você pode:
- Ver todas as mamadas registradas
- Filtrar por data
- Ver estatísticas por período
- Editar ou excluir registros

### Sistema de Notificações

O aplicativo pode enviar lembretes úteis:

#### Configurando Notificações

1. Acesse as configurações
2. Ative as notificações desejadas:
   - Lembretes de mamadas
   - Dica diária
   - Marcos de desenvolvimento

#### Tipos de Notificações

- **Lembrete de Mamada**: Baseado no padrão do seu bebê
- **Dica Diária**: Uma dica personalizada todo dia
- **Marcos**: Lembretes sobre marcos de desenvolvimento

## Dicas de Uso

### Para Mães de Primeira Viagem

1. **Não se preocupe com a perfeição**: Cada bebê é único e pode ter necessidades diferentes das recomendações gerais.

2. **Use como guia, não como regra**: As informações do app são orientações baseadas em evidências científicas, mas sempre observe seu bebê.

3. **Registre regularmente**: Manter um registro das mamadas ajuda a identificar padrões e facilita conversas com o pediatra.

4. **Leia as dicas diárias**: Elas são selecionadas especificamente para a idade do seu bebê.

5. **Confie no seu instinto**: Se algo parecer errado com seu bebê, procure ajuda médica independentemente do que o app sugere.

### Maximizando o Uso do App

1. **Mantenha os dados atualizados**: Certifique-se de que a data de nascimento está correta.

2. **Use as notificações**: Elas podem ajudar a estabelecer rotinas.

3. **Explore todas as categorias de dicas**: Cada uma oferece informações valiosas.

4. **Compartilhe com o parceiro**: Ambos os pais podem usar o app para estar alinhados nos cuidados.

## Solução de Problemas

### Problemas Comuns

**O app não está mostrando dicas para minha idade do bebê**
- Verifique se a data de nascimento está correta
- Certifique-se de que o perfil do bebê foi salvo
- Tente fechar e abrir o app novamente

**Não estou recebendo notificações**
- Verifique se as notificações estão ativadas nas configurações do app
- Confirme se as notificações estão permitidas nas configurações do seu celular
- Reinicie o aplicativo

**Esqueci minha senha**
- Na tela de login, toque em "Esqueci minha senha"
- Siga as instruções enviadas para seu email

**O app está lento ou travando**
- Feche outros aplicativos em execução
- Reinicie seu celular
- Certifique-se de ter espaço suficiente no dispositivo

### Quando Buscar Ajuda Médica

O MãeConecta é uma ferramenta de apoio, mas não substitui o acompanhamento médico. Procure seu pediatra imediatamente se o bebê apresentar:

- Febre alta
- Dificuldade para respirar
- Vômitos persistentes
- Diarreia com sangue
- Irritabilidade excessiva
- Sonolência anormal
- Recusa total de alimentação
- Qualquer comportamento que te preocupe

## Configurações e Personalização

### Acessando Configurações

1. Toque no ícone de perfil na tela inicial
2. Selecione "Configurações"

### Opções Disponíveis

- **Notificações**: Ativar/desativar diferentes tipos
- **Perfil**: Editar informações pessoais
- **Bebê**: Atualizar dados do bebê
- **Privacidade**: Gerenciar dados pessoais
- **Sobre**: Informações do aplicativo

## Segurança e Privacidade

### Seus Dados Estão Seguros

- Todas as informações são armazenadas localmente no seu dispositivo
- Não compartilhamos dados pessoais com terceiros
- Você pode excluir seus dados a qualquer momento

### Backup de Dados

Recomendamos fazer backup regular dos dados importantes:
- Anote as informações principais em um caderno
- Tire screenshots dos relatórios importantes
- Mantenha um registro físico como backup

## Suporte e Feedback

### Precisa de Ajuda?

Se você encontrar problemas ou tiver sugestões:

1. Verifique este manual primeiro
2. Consulte a seção de problemas comuns
3. Entre em contato através das configurações do app

### Sua Opinião é Importante

Ajude-nos a melhorar o MãeConecta:
- Avalie o app na loja de aplicativos
- Compartilhe suas experiências
- Sugira novas funcionalidades

## Atualizações

### Mantendo o App Atualizado

- Ative as atualizações automáticas na loja de aplicativos
- Verifique regularmente se há novas versões
- Leia as notas de atualização para conhecer novidades

### O que Esperar em Futuras Versões

- Mais dicas personalizadas
- Gráficos de crescimento
- Integração com dispositivos de saúde
- Comunidade de mães
- Consultas virtuais

## Conclusão

O MãeConecta foi criado com muito carinho para apoiar você nesta jornada maravilhosa da maternidade. Lembre-se de que ser mãe é um aprendizado constante, e está tudo bem não saber tudo desde o início.

Use este aplicativo como seu companheiro de confiança, mas sempre confie no seu instinto materno e mantenha o acompanhamento regular com o pediatra do seu bebê.

Desejamos a você e seu bebê muita saúde e felicidade! 💕

---

**Versão do Manual**: 1.0  
**Última Atualização**: Dezembro 2024  
**Compatibilidade**: MãeConecta v1.0+

