# Configuração Específica para FlutterFlow - MãeConecta

## Checklist de Preparação

### ✅ Arquivos Essenciais Incluídos
- [x] `pubspec.yaml` configurado com todas as dependências
- [x] Estrutura de pastas organizada (`lib/`, `assets/`)
- [x] Modelos de dados completos
- [x] Serviços implementados
- [x] Telas principais criadas
- [x] Documentação completa

### ✅ Compatibilidade FlutterFlow
- [x] Dependências compatíveis selecionadas
- [x] Código estruturado para importação
- [x] Comentários em português para Luis e Grupo PIME
- [x] Sem referências a IA no código

## Dependências Verificadas para FlutterFlow

### ✅ Compatíveis
```yaml
provider: ^6.0.5          # Gerenciamento de estado
go_router: ^10.1.2        # Navegação
shared_preferences: ^2.2.0 # Armazenamento local
intl: ^0.18.1             # Internacionalização
```

### ⚠️ Requerem Configuração
```yaml
sqflite: ^2.3.0                      # Banco local - pode precisar de setup
flutter_local_notifications: ^15.1.0 # Notificações - requer permissões
```

### 🔄 Alternativas Recomendadas para FlutterFlow
- **SQLite** → **Firestore** (melhor integração)
- **Local Storage** → **Firebase Storage** (sincronização)
- **Local Notifications** → **Firebase Cloud Messaging** (push notifications)

## Estrutura de Importação

### 1. Arquivos Principais
```
maeconecta_flutter/
├── pubspec.yaml          # IMPORTANTE: Revisar dependências
├── lib/main.dart         # Ponto de entrada
└── lib/                  # Código fonte completo
```

### 2. Modelos de Dados
```
lib/models/
├── user.dart            # Modelo do usuário
├── baby.dart            # Modelo do bebê
├── feeding_record.dart  # Registros de mamadas
└── tip.dart             # Dicas personalizadas
```

### 3. Serviços
```
lib/services/
├── auth_service.dart         # Autenticação
├── baby_service.dart         # Gerenciamento do bebê
├── feeding_service.dart      # Registros de alimentação
├── tips_service.dart         # Sistema de dicas
└── notification_service.dart # Notificações
```

### 4. Telas
```
lib/screens/
├── splash_screen.dart           # Tela inicial
├── login_screen.dart            # Login
├── register_screen.dart         # Registro
├── home_screen.dart             # Dashboard principal
├── baby_profile_screen.dart     # Perfil do bebê
├── feeding_calculator_screen.dart # Calculadora
├── tips_screen.dart             # Dicas
├── feeding_log_screen.dart      # Histórico
└── profile_screen.dart          # Perfil do usuário
```

## Configurações Específicas para FlutterFlow

### 1. Navegação
**Rotas Configuradas:**
- `/splash` → SplashScreen
- `/login` → LoginScreen
- `/register` → RegisterScreen
- `/home` → HomeScreen (principal)
- `/baby-profile` → BabyProfileScreen
- `/feeding-calculator` → FeedingCalculatorScreen
- `/tips` → TipsScreen
- `/feeding-log` → FeedingLogScreen
- `/profile` → ProfileScreen

### 2. Estado Global (Provider)
**Providers Configurados:**
- `AuthService`: Gerencia autenticação
- `BabyService`: Gerencia dados do bebê
- `FeedingService`: Gerencia registros de alimentação
- `TipsService`: Gerencia dicas personalizadas

### 3. Tema e Cores
**Paleta de Cores:**
```dart
Primary: #6B73FF
Secondary: #4CAF50
Background: #FFFFFF
Surface: #F5F5F5
Error: #F44336
```

## Adaptações Necessárias para FlutterFlow

### 1. Banco de Dados
**Atual (SQLite):**
```dart
// Armazenamento local com SQLite
```

**Recomendado (Firestore):**
```dart
// Migrar para Firestore para melhor integração
// Configurar coleções: users, babies, feeding_records, tips
```

### 2. Autenticação
**Atual (Local):**
```dart
// Sistema de autenticação local
```

**Recomendado (Firebase Auth):**
```dart
// Usar Firebase Authentication do FlutterFlow
// Configurar providers: email/password
```

### 3. Notificações
**Atual (Local):**
```dart
// Flutter Local Notifications
```

**Recomendado (FCM):**
```dart
// Firebase Cloud Messaging
// Configurar através do FlutterFlow
```

## Instruções de Importação

### Passo 1: Preparar Arquivos
1. Compactar toda a pasta `maeconecta_flutter/` em ZIP
2. Verificar se todos os arquivos estão incluídos
3. Confirmar que não há referências a caminhos absolutos

### Passo 2: Importar no FlutterFlow
1. Criar novo projeto no FlutterFlow
2. Selecionar "Import from Code"
3. Fazer upload do arquivo ZIP
4. Aguardar processamento

### Passo 3: Configurar Dependências
1. Revisar dependências no FlutterFlow
2. Adicionar dependências não reconhecidas
3. Configurar versões compatíveis

### Passo 4: Configurar Firebase (Recomendado)
1. Criar projeto Firebase
2. Configurar Authentication
3. Configurar Firestore
4. Configurar Cloud Messaging

### Passo 5: Testar Funcionalidades
1. Testar navegação entre telas
2. Verificar providers funcionando
3. Testar formulários e validações
4. Confirmar tema aplicado

## Código Personalizado para FlutterFlow

### Widgets Personalizados Incluídos
- `TipCard`: Card de dica personalizada
- `FeedingRecordCard`: Card de registro de mamada
- `BabyInfoCard`: Card de informações do bebê
- `StatCard`: Card de estatística

### Funções Utilitárias
- `formatDuration()`: Formatar duração
- `calculateAge()`: Calcular idade do bebê
- `getFeedingRecommendation()`: Obter recomendações
- `validateEmail()`: Validar email

## Testes Recomendados

### 1. Teste de Importação
- [ ] Projeto importa sem erros
- [ ] Todas as dependências são reconhecidas
- [ ] Estrutura de pastas mantida

### 2. Teste de Funcionalidades
- [ ] Navegação funciona
- [ ] Formulários validam corretamente
- [ ] Estado é mantido entre telas
- [ ] Tema é aplicado consistentemente

### 3. Teste de Build
- [ ] Build Android funciona
- [ ] Build iOS funciona (se aplicável)
- [ ] Não há erros de compilação
- [ ] App executa no simulador

## Solução de Problemas Comuns

### Erro: Dependência não encontrada
**Solução:** Adicionar manualmente no FlutterFlow ou usar alternativa compatível

### Erro: Código personalizado não funciona
**Solução:** Verificar sintaxe Dart e imports corretos

### Erro: Navegação não funciona
**Solução:** Configurar rotas manualmente no FlutterFlow

### Erro: Estado não persiste
**Solução:** Verificar configuração dos Providers

## Notas Importantes para Luis e Grupo PIME

### ⚠️ Atenção Especial
1. **Backup**: Sempre manter backup do código original
2. **Testes**: Testar cada funcionalidade após importação
3. **Documentação**: Consultar documentação antes de modificar
4. **Versionamento**: Manter controle de versões das alterações

### 🔧 Customizações Futuras
1. **Cores**: Podem ser alteradas no tema do FlutterFlow
2. **Textos**: Todos os textos estão em português
3. **Funcionalidades**: Código modular permite adições fáceis
4. **Integrações**: Preparado para integrações futuras

### 📱 Deploy
1. **Android**: Configurar certificados e permissões
2. **iOS**: Configurar provisioning profiles
3. **Testes**: Testar em dispositivos reais
4. **Publicação**: Seguir guias das lojas de aplicativos

---

**Este arquivo deve ser consultado durante todo o processo de importação e configuração no FlutterFlow.**

