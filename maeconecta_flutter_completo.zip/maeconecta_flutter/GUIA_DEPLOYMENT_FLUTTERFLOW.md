# Guia de Deployment no FlutterFlow - MãeConecta

## Introdução

Este guia fornece instruções detalhadas para importar e fazer o deployment do aplicativo MãeConecta no FlutterFlow. O FlutterFlow é uma plataforma visual que permite desenvolver aplicativos Flutter sem escrever código, mas também suporta importação de projetos Flutter existentes.

## Pré-requisitos

### Conta FlutterFlow

1. Acesse [flutterflow.io](https://flutterflow.io)
2. Crie uma conta ou faça login
3. Certifique-se de ter um plano que suporte importação de código personalizado

### Arquivos Necessários

Certifique-se de ter todos os arquivos do projeto MãeConecta:
- Código fonte Flutter completo
- Arquivo `pubspec.yaml` configurado
- Assets e recursos
- Documentação

## Preparação do Projeto

### 1. Estrutura de Arquivos

Antes de importar para o FlutterFlow, organize os arquivos conforme a estrutura esperada:

```
maeconecta_flutter/
├── lib/
│   ├── main.dart
│   ├── models/
│   ├── screens/
│   ├── services/
│   ├── widgets/
│   └── utils/
├── assets/
│   ├── images/
│   └── fonts/
├── pubspec.yaml
├── README.md
└── documentação/
```

### 2. Verificação de Dependências

Revise o arquivo `pubspec.yaml` e certifique-se de que todas as dependências são compatíveis com FlutterFlow:

**Dependências Principais Compatíveis:**
- `flutter`: SDK principal
- `provider`: Gerenciamento de estado
- `go_router`: Navegação
- `shared_preferences`: Armazenamento local
- `http`: Requisições de rede
- `intl`: Internacionalização

**Dependências que Podem Precisar de Ajustes:**
- `flutter_local_notifications`: Verificar compatibilidade
- `sqflite`: Pode precisar de configuração adicional

### 3. Configuração de Assets

Certifique-se de que todos os assets estão corretamente declarados no `pubspec.yaml`:

```yaml
flutter:
  assets:
    - assets/images/
    - assets/fonts/
  
  fonts:
    - family: Roboto
      fonts:
        - asset: assets/fonts/Roboto-Regular.ttf
        - asset: assets/fonts/Roboto-Bold.ttf
          weight: 700
```

## Processo de Importação

### Método 1: Importação Direta (Recomendado)

1. **Criar Novo Projeto no FlutterFlow**
   - Acesse o dashboard do FlutterFlow
   - Clique em "Create New Project"
   - Selecione "Import from Code"
   - Escolha "Flutter Project"

2. **Upload dos Arquivos**
   - Compacte todo o projeto em um arquivo ZIP
   - Faça upload do arquivo ZIP
   - Aguarde o processamento da importação

3. **Configuração Inicial**
   - Revise as configurações do projeto
   - Verifique se todas as dependências foram reconhecidas
   - Configure as variáveis de ambiente se necessário

### Método 2: Criação Manual (Alternativo)

Se a importação direta não funcionar, você pode recriar o projeto manualmente:

1. **Criar Projeto Base**
   - Crie um novo projeto Flutter no FlutterFlow
   - Configure o nome como "MãeConecta"
   - Selecione as configurações básicas

2. **Adicionar Dependências**
   - Vá para "Settings" > "Dependencies"
   - Adicione cada dependência do `pubspec.yaml`
   - Configure as versões conforme necessário

3. **Importar Código Personalizado**
   - Use a funcionalidade "Custom Code"
   - Adicione os modelos de dados
   - Importe os serviços
   - Configure as telas principais

## Configuração de Funcionalidades

### 1. Autenticação

**Configuração no FlutterFlow:**
1. Vá para "Authentication" nas configurações
2. Configure "Email/Password Authentication"
3. Ative "Allow Users to Create Account"
4. Configure redirecionamentos pós-login

**Integração com Código Personalizado:**
- Mantenha o `AuthService` como código personalizado
- Configure callbacks para integração com FlutterFlow Auth

### 2. Banco de Dados

**Opção 1: Firestore (Recomendado para FlutterFlow)**
1. Configure Firebase no projeto
2. Ative Firestore Database
3. Migre os modelos de dados para Firestore
4. Atualize os serviços para usar Firestore

**Opção 2: Manter SQLite Local**
- Mantenha o código atual de SQLite
- Configure como código personalizado
- Pode ter limitações na interface visual

### 3. Notificações

1. **Firebase Cloud Messaging**
   - Configure FCM no projeto Firebase
   - Adicione as configurações no FlutterFlow
   - Teste as notificações push

2. **Notificações Locais**
   - Mantenha o `NotificationService` como código personalizado
   - Configure permissões necessárias

### 4. Navegação

**Configuração de Rotas:**
1. Configure as rotas principais no FlutterFlow:
   - `/splash` → SplashScreen
   - `/login` → LoginScreen
   - `/register` → RegisterScreen
   - `/home` → HomeScreen
   - `/baby-profile` → BabyProfileScreen
   - `/feeding-calculator` → FeedingCalculatorScreen
   - `/tips` → TipsScreen
   - `/feeding-log` → FeedingLogScreen
   - `/profile` → ProfileScreen

2. **Configurar Redirecionamentos:**
   - Configure lógica de redirecionamento baseada em autenticação
   - Defina tela inicial apropriada

## Configuração de Temas

### 1. Cores e Estilo

Configure o tema no FlutterFlow para corresponder ao design do MãeConecta:

**Cores Principais:**
- Primary: `#6B73FF`
- Secondary: `#4CAF50`
- Background: `#FFFFFF`
- Surface: `#F5F5F5`

**Tipografia:**
- Font Family: Roboto
- Tamanhos: 12, 14, 16, 18, 24, 32

### 2. Componentes Personalizados

Crie componentes reutilizáveis no FlutterFlow:
- Card de dica
- Botão de ação rápida
- Item de histórico de mamada
- Indicador de estatística

## Testes e Validação

### 1. Teste no Simulador

1. Use o simulador integrado do FlutterFlow
2. Teste todas as funcionalidades principais:
   - Login e registro
   - Cadastro de bebê
   - Calculadora de amamentação
   - Sistema de dicas
   - Registro de mamadas

### 2. Teste em Dispositivo Real

1. Use o FlutterFlow Viewer app
2. Escaneie o QR code do projeto
3. Teste em dispositivos Android e iOS
4. Verifique performance e usabilidade

### 3. Validação de Funcionalidades

**Checklist de Testes:**
- [ ] Autenticação funciona corretamente
- [ ] Dados do bebê são salvos e carregados
- [ ] Calculadora mostra recomendações corretas
- [ ] Dicas são exibidas por categoria de idade
- [ ] Registros de mamada são salvos
- [ ] Notificações funcionam
- [ ] Navegação entre telas está fluida
- [ ] Interface é responsiva

## Deployment para Lojas

### 1. Configuração para Android

**Play Store:**
1. Configure o bundle ID único
2. Gere o APK/AAB através do FlutterFlow
3. Configure ícones e splash screens
4. Adicione descrições e screenshots
5. Configure permissões necessárias

**Permissões Necessárias:**
```xml
<uses-permission android:name="android.permission.INTERNET" />
<uses-permission android:name="android.permission.WAKE_LOCK" />
<uses-permission android:name="android.permission.RECEIVE_BOOT_COMPLETED" />
<uses-permission android:name="android.permission.VIBRATE" />
```

### 2. Configuração para iOS

**App Store:**
1. Configure o bundle ID único
2. Gere o IPA através do FlutterFlow
3. Configure certificados de desenvolvimento/distribuição
4. Adicione ícones em todas as resoluções
5. Configure Info.plist com permissões

**Configurações Info.plist:**
```xml
<key>NSUserNotificationsUsageDescription</key>
<string>Este app usa notificações para lembretes de mamadas e dicas diárias.</string>
```

## Manutenção e Atualizações

### 1. Versionamento

Configure versionamento adequado:
- Version: 1.0.0
- Build Number: Incremental
- Mantenha changelog atualizado

### 2. Monitoramento

Configure analytics e crash reporting:
- Firebase Analytics
- Crashlytics
- Performance Monitoring

### 3. Atualizações de Conteúdo

**Dicas e Recomendações:**
- Configure sistema para atualizar dicas remotamente
- Use Firebase Remote Config
- Mantenha backup das dicas atuais

## Solução de Problemas

### Problemas Comuns

**1. Dependências Incompatíveis**
- Verifique versões no FlutterFlow
- Use versões compatíveis
- Considere alternativas se necessário

**2. Código Personalizado Não Funciona**
- Verifique sintaxe Dart
- Confirme imports corretos
- Teste isoladamente

**3. Build Falha**
- Revise logs de erro
- Verifique configurações de plataforma
- Confirme permissões

**4. Performance Lenta**
- Otimize imagens e assets
- Reduza widgets desnecessários
- Use lazy loading quando possível

### Logs e Debug

**Acessando Logs:**
1. Use o console do FlutterFlow
2. Ative debug mode
3. Monitore performance
4. Analise crash reports

## Configurações Avançadas

### 1. Integração com APIs Externas

Se necessário integrar com APIs:
1. Configure endpoints no FlutterFlow
2. Adicione autenticação de API
3. Configure tratamento de erros
4. Teste conectividade

### 2. Customizações Específicas

**Para Luis e Grupo PIME:**
- Mantenha documentação de customizações
- Use comentários descritivos no código
- Configure variáveis de ambiente para diferentes ambientes
- Implemente feature flags para funcionalidades experimentais

### 3. Backup e Recuperação

Configure estratégias de backup:
- Export regular do projeto FlutterFlow
- Backup do código fonte
- Documentação de configurações
- Plano de recuperação de desastres

## Considerações de Segurança

### 1. Dados Sensíveis

- Não inclua chaves de API no código
- Use variáveis de ambiente
- Configure obfuscação de código
- Implemente validação de entrada

### 2. Comunicação Segura

- Use HTTPS para todas as comunicações
- Valide certificados SSL
- Implemente timeout adequado
- Configure retry policies

## Suporte e Recursos

### Documentação Oficial

- [FlutterFlow Documentation](https://docs.flutterflow.io)
- [Flutter Documentation](https://flutter.dev/docs)
- [Firebase Documentation](https://firebase.google.com/docs)

### Comunidade

- FlutterFlow Community Forum
- Flutter Discord
- Stack Overflow (tag: flutterflow)

### Contato para Suporte

Para questões específicas do projeto MãeConecta:
1. Consulte esta documentação primeiro
2. Verifique logs de erro
3. Entre em contato com a equipe de desenvolvimento

## Conclusão

Este guia fornece uma base sólida para fazer o deployment do MãeConecta no FlutterFlow. Lembre-se de:

1. Testar extensivamente antes do deployment
2. Manter backups regulares
3. Monitorar performance pós-deployment
4. Coletar feedback dos usuários
5. Planejar atualizações regulares

O sucesso do deployment depende de seguir cuidadosamente cada etapa e adaptar as instruções conforme necessário para seu ambiente específico.

---

**Nota Importante para Luis e Grupo PIME**: Este guia deve ser seguido passo a passo. Em caso de dúvidas ou problemas, consulte a documentação oficial do FlutterFlow ou entre em contato com o suporte técnico. Mantenha sempre um backup do projeto antes de fazer alterações significativas.

